-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 27, 2019 at 03:29 PM
-- Server version: 10.1.40-MariaDB
-- PHP Version: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `resource_network`
--

-- --------------------------------------------------------

--
-- Table structure for table `access_level`
--

CREATE TABLE `access_level` (
  `id` int(11) NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `access_level`
--

INSERT INTO `access_level` (`id`, `status`) VALUES
(1, '5'),
(2, '4'),
(3, '3'),
(4, '2'),
(5, '1');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `firstname` text NOT NULL,
  `lastname` text NOT NULL,
  `email` text NOT NULL,
  `gender` text NOT NULL,
  `admin_id` text NOT NULL,
  `password` text NOT NULL,
  `phonenumber` varchar(14) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `picture` text NOT NULL,
  `position` int(11) NOT NULL,
  `logged` datetime NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `firstname`, `lastname`, `email`, `gender`, `admin_id`, `password`, `phonenumber`, `status`, `picture`, `position`, `logged`, `date`) VALUES
(1, 'Dickson', 'Ifediora', 'soft@gmail.com', 'Gender', 'A100', 'fcea920f7412b5da7be0cf42b8c93759', '08064587230', 1, '20151214_165349.jpg', 5, '2019-07-24 14:04:06', '0000-00-00 00:00:00'),
(2, 'David', 'Beckham', 'beckham@gmail.com', 'male', 'A200', 'fcea920f7412b5da7be0cf42b8c93759', '8054595910', 0, '', 4, '2017-11-01 04:20:35', '2017-10-18 15:07:41'),
(3, 'Hemueing', 'Son', 'son@gmail.com', 'male', 'A300', 'fcea920f7412b5da7be0cf42b8c93759', '8034347676', 0, '', 2, '0000-00-00 00:00:00', '2017-10-24 13:53:36'),
(4, 'Sergio ', 'Ramos', 'ramos@gmail.com', '', 'A102', 'fcea920f7412b5da7be0cf42b8c93759', '', 1, '', 2, '2018-01-08 11:01:14', '2017-12-14 10:57:59');

-- --------------------------------------------------------

--
-- Table structure for table `adminmessage`
--

CREATE TABLE `adminmessage` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `subject` text NOT NULL,
  `message` text NOT NULL,
  `status` int(11) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adminmessage`
--

INSERT INTO `adminmessage` (`id`, `name`, `subject`, `message`, `status`, `date`) VALUES
(1, 'Dubesoft', 'Withdrawal', 'I tried withdrawing, the system debited me without paying me.', 3, '2017-11-06 06:14:10'),
(2, 'Dubem', 'Complain', 'The system  refused to grant me loan', 0, '2017-11-14 10:55:51'),
(3, 'Dubem', 'Complain', 'The system  refused to grant me loan', 0, '2017-11-14 10:56:35'),
(4, 'serena', 'loan issue', 'am serena havent been able to apply for loan thou i have no money in the account', 0, '2017-11-14 15:45:38');

-- --------------------------------------------------------

--
-- Table structure for table `config`
--

CREATE TABLE `config` (
  `id` int(11) NOT NULL,
  `savings_count` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `deposit`
--

CREATE TABLE `deposit` (
  `id` int(11) NOT NULL,
  `member_id` text NOT NULL,
  `amount` int(11) NOT NULL,
  `narration` text NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `deposit`
--

INSERT INTO `deposit` (`id`, `member_id`, `amount`, `narration`, `date`) VALUES
(1, 'm200', 1240, 'DsiHUB Asaba', '2017-11-13 08:58:59'),
(2, 'm606', 1000, 'Zenith Bank Asaba', '2017-11-13 09:00:54'),
(3, 'm100', 4000, 'At Science and Tech. Asaba', '2017-11-13 22:41:00'),
(4, 'm100', 200, 'At Asaba Delta State ', '2017-11-13 22:42:16'),
(5, 'm100', 300, 'At Asaba Delta State ', '2017-11-13 22:42:47'),
(6, 'm100', 2000, 'At Zenith Bank ', '2017-11-20 03:06:08'),
(7, 'm100', 56000, 'At Science and Tech. Asaba', '2017-11-27 09:30:29');

-- --------------------------------------------------------

--
-- Table structure for table `loan`
--

CREATE TABLE `loan` (
  `id` int(11) NOT NULL,
  `member_id` text NOT NULL,
  `amount` int(11) NOT NULL,
  `loantype_id` int(11) NOT NULL,
  `interest` int(11) NOT NULL,
  `duration` text NOT NULL,
  `status` int(11) NOT NULL,
  `reason` text NOT NULL,
  `narration` text NOT NULL,
  `approved_date` datetime NOT NULL,
  `applied_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `loan`
--

INSERT INTO `loan` (`id`, `member_id`, `amount`, `loantype_id`, `interest`, `duration`, `status`, `reason`, `narration`, `approved_date`, `applied_date`) VALUES
(1, 'm100', 2000, 1, 5, '4', 0, 'Salary', '', '0000-00-00 00:00:00', '2017-10-24 16:22:09'),
(2, 'm100', 34000, 1, 5, '4', 0, 'Education', '', '0000-00-00 00:00:00', '2017-10-18 11:18:57'),
(3, 'm300', 54000, 1, 5, '4', 0, 'Medical', '', '0000-00-00 00:00:00', '2017-10-18 11:20:24'),
(4, 'm100', 54000, 1, 5, '4', 3, 'Medical', '', '0000-00-00 00:00:00', '2017-10-18 11:20:24'),
(5, 'm200', 47339, 1, 5, '4', 0, 'Transport', '', '0000-00-00 00:00:00', '2017-10-18 11:27:41'),
(6, '0', 47339, 1, 5, '4', 1, 'Transport', '', '0000-00-00 00:00:00', '2017-10-18 11:27:41'),
(7, '0', 5600, 1, 5, '4', 1, 'Feeding', '', '0000-00-00 00:00:00', '2017-10-18 11:30:17'),
(8, '0', 5600, 1, 5, '4', 1, 'Feeding', '', '0000-00-00 00:00:00', '2017-10-18 11:30:17'),
(9, '0', 2398, 1, 5, '4', 1, 'Test', '', '0000-00-00 00:00:00', '2017-10-18 11:33:14'),
(10, '0', 2398, 1, 5, '4', 1, 'Test', '', '0000-00-00 00:00:00', '2017-10-18 11:33:14'),
(11, '0', 21000, 1, 5, '4', 1, 'Exam', '', '0000-00-00 00:00:00', '2017-10-18 11:35:00'),
(12, '0', 37200, 1, 5, '4', 0, 'Leave', '', '0000-00-00 00:00:00', '2017-10-18 11:48:29'),
(13, '0', 3500, 1, 5, '4', 0, 'Health', '', '0000-00-00 00:00:00', '2017-10-18 17:50:38'),
(14, '0', 21000, 1, 5, '4', 0, 'Test', '', '0000-00-00 00:00:00', '2017-10-19 12:53:53'),
(15, '0', 34000, 1, 5, '4', 0, 'Medical', '', '0000-00-00 00:00:00', '2017-10-19 14:49:19'),
(16, '0', 54230, 1, 5, '4', 0, 'Emergency', '', '0000-00-00 00:00:00', '2017-10-19 14:51:01'),
(17, '0', 4000, 1, 5, '4', 0, 'Emergency', '', '0000-00-00 00:00:00', '2017-10-19 14:54:53'),
(18, '0', 36000, 1, 5, '4', 0, 'Holiday', '', '0000-00-00 00:00:00', '2017-10-19 20:03:14'),
(19, '0', 45999, 1, 5, '4', 0, 'Education', '', '0000-00-00 00:00:00', '2017-10-19 23:59:43'),
(20, '0', 12000, 1, 5, '4', 0, 'Heavy', '', '0000-00-00 00:00:00', '2017-10-20 00:05:07'),
(21, '0', 56400, 1, 5, '4', 0, 'Medical', '', '0000-00-00 00:00:00', '2017-10-20 00:07:12'),
(22, '0', 26000, 1, 5, '4', 0, 'Feeding', '', '0000-00-00 00:00:00', '2017-10-20 00:07:38'),
(23, '', 323344, 3, 10, '3', 0, 'Test', '', '0000-00-00 00:00:00', '2017-11-13 14:38:36'),
(24, '', 5100, 3, 10, '3', 0, 'Test', '', '0000-00-00 00:00:00', '2017-11-13 14:39:18'),
(25, '', 200, 3, 10, '3', 0, 'Test', '', '0000-00-00 00:00:00', '2017-11-13 14:39:44'),
(26, '', 500, 3, 10, '3', 0, 'Salary', '', '0000-00-00 00:00:00', '2017-11-13 14:43:00'),
(27, '', 50000, 3, 10, '3', 0, 'Emergency', '', '0000-00-00 00:00:00', '2017-11-13 14:57:04'),
(28, '', 3000, 3, 10, '3', 0, 'Emergency', '', '0000-00-00 00:00:00', '2017-11-13 14:58:10'),
(29, '', 45000, 3, 10, '3', 0, 'Emergency', '', '0000-00-00 00:00:00', '2017-11-13 15:00:13'),
(30, '', 4500, 3, 10, '3', 0, 'Emergency', '', '0000-00-00 00:00:00', '2017-11-13 15:00:26'),
(31, '', 200, 3, 10, '3', 0, 'Emergency', '', '0000-00-00 00:00:00', '2017-11-13 15:06:52'),
(32, '', 4000, 3, 5, '3', 0, 'travel', '', '0000-00-00 00:00:00', '2017-11-13 18:00:56'),
(33, '', 4900, 3, 5, '3', 0, 'Expenses', '', '0000-00-00 00:00:00', '2017-11-13 18:19:25'),
(34, '', 3700, 4, 10, '12', 0, 'trip', '', '0000-00-00 00:00:00', '2017-11-13 18:20:26'),
(35, 'm100', 4100, 3, 5, '3', 0, 'medical', '', '0000-00-00 00:00:00', '2017-11-13 18:23:29'),
(36, 'm300', 4200, 4, 10, '12', 0, 'Health', '', '0000-00-00 00:00:00', '2017-11-13 18:24:58'),
(37, 'm100', 1000, 3, 5, '3', 0, 'trip', '', '0000-00-00 00:00:00', '2017-11-14 16:03:05'),
(38, 'm100', 10000, 3, 5, '3', 0, 'medical', '', '0000-00-00 00:00:00', '2017-11-14 17:11:33'),
(39, 'm100', 100000, 3, 5, '3', 0, 'medical', '', '0000-00-00 00:00:00', '2017-11-14 17:22:41'),
(40, '', 12000, 3, 5, '3', 0, 'vacation', '', '0000-00-00 00:00:00', '2017-11-20 23:29:47'),
(41, '', 4000, 3, 5, '3', 0, 'vacation', '', '0000-00-00 00:00:00', '2017-11-20 23:30:11');

-- --------------------------------------------------------

--
-- Table structure for table `loantype`
--

CREATE TABLE `loantype` (
  `id` int(11) NOT NULL,
  `loantype` text NOT NULL,
  `max_credit` text NOT NULL,
  `PSR` text NOT NULL,
  `interest_rate` text NOT NULL,
  `max_duration` text NOT NULL,
  `narration` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `loantype`
--

INSERT INTO `loantype` (`id`, `loantype`, `max_credit`, `PSR`, `interest_rate`, `max_duration`, `narration`) VALUES
(1, '1', '50000', '10', '5', '4', 'Affordability'),
(2, '3', '3', '3', '3030', '3', 'Help'),
(3, 'christmas', '5000', '8', '5', '3', 'Help'),
(4, 'sallah', '34000', '20', '10', '12', 'Sallah Loan set up by Dickson on 13-11-2017');

-- --------------------------------------------------------

--
-- Table structure for table `logged`
--

CREATE TABLE `logged` (
  `id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `narration` text NOT NULL,
  `date` datetime NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE `members` (
  `id` int(11) NOT NULL,
  `staff_id` text NOT NULL,
  `firstname` text NOT NULL,
  `lastname` text NOT NULL,
  `password` text NOT NULL,
  `email` text NOT NULL,
  `address` text NOT NULL,
  `phonenumber` varchar(255) NOT NULL,
  `gender` text NOT NULL,
  `savedbalance` int(50) NOT NULL,
  `status` text NOT NULL,
  `picture` text NOT NULL,
  `logged` datetime NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`id`, `staff_id`, `firstname`, `lastname`, `password`, `email`, `address`, `phonenumber`, `gender`, `savedbalance`, `status`, `picture`, `logged`, `date`) VALUES
(1, 'm100', 'Oscar', 'brown', '1234567', 'brown@gmail.com', 'Traffic Light', '08134591104', 'Gender', 254000, '1', '04102015325.jpg', '2017-11-14 16:42:26', '2017-08-01 09:10:12'),
(2, 'm200', 'Gabriel', 'Jesus', 'fcea920f7412b5da7be0cf42b8c93759', 'jesus@gmail.com', 'Manchester', '8056734826', 'male', 940, '0', '', '0000-00-00 00:00:00', '2017-10-18 15:16:47'),
(3, 'm300', 'Elton', 'Chisom', 'fcea920f7412b5da7be0cf42b8c93759', 'chisom@gmail.com', 'Alaba International', '08054595910', 'Gender', 229700, '1', 'win_20171029_07_08_56_pro.jpg', '2017-11-27 09:33:33', '2017-10-20 04:23:10'),
(4, 'm400', 'Henry', 'ugo', 'fcea920f7412b5da7be0cf42b8c93759', 'ugo@yahoo.com', 'Afromedia', '08045362789', 'male', 90023400, '1', 'jerex.jpg', '0000-00-00 00:00:00', '2017-10-19 08:18:21'),
(5, 'm606', 'John', 'Kennex', 'fcea920f7412b5da7be0cf42b8c93759', 'kennex@hotmail.cm', 'Atlanta, usa', '8074563245', 'male', 1000, '1', '', '0000-00-00 00:00:00', '2017-10-24 13:39:42'),
(6, 'm607', 'Michael', 'Jackson', 'fcea920f7412b5da7be0cf42b8c93759', 'jackson@gmail.com', 'New Jersy, USA', '8064532349', 'male', 0, '1', '', '0000-00-00 00:00:00', '2017-10-24 13:42:59'),
(7, '608', 'Jenna', 'Kyle', 'fcea920f7412b5da7be0cf42b8c93759', 'jenna@yahoo.com', 'Oklahoma', '9046572839', 'female', 0, '0', '', '0000-00-00 00:00:00', '2017-10-24 13:45:17'),
(8, '12', 'Zino', 'dickson2', '5d793fc5b00a2348c3fb9ab59e5ca98a', 'sere@gmail.com', '', '', 'Gender', 100, '1', '', '2017-11-14 15:57:37', '0000-00-00 00:00:00'),
(9, 'm700', 'Kelvin', 'Nelson', 'fcea920f7412b5da7be0cf42b8c93759', 'kelviin@gmail.com', '', '', '', 0, '0', '', '0000-00-00 00:00:00', '2017-11-14 16:52:27'),
(10, '45', 'r', 'r', '5d793fc5b00a2348c3fb9ab59e5ca98a', 'rgg', '', '', '', 0, '0', '', '0000-00-00 00:00:00', '2017-11-14 16:53:28'),
(11, 'm200', 'sam', 'dickson', '5d793fc5b00a2348c3fb9ab59e5ca98a', 'samueldavidnkem@gmail.com', '', '', '', 0, '0', '', '0000-00-00 00:00:00', '2017-11-14 16:56:16'),
(12, 'm800', 'Luka', 'Modric', 'fcea920f7412b5da7be0cf42b8c93759', 'luka@gmail.com', '', '', '', 0, '1', '', '0000-00-00 00:00:00', '2017-12-14 11:01:50'),
(13, '12', 'samuel', 'serena', '7e701d382bc9c8d09877385e2b34d565', 'samuelserenaluv@gmail.com', '', '', '', 0, '0', '', '0000-00-00 00:00:00', '2018-02-17 06:34:11'),
(14, '12', 'serena', 'samuel', 'a88d4a13b65c49cf68ffbac4db7fdc29', 'samuel@gmail', '', '', '', 0, '0', '', '0000-00-00 00:00:00', '2019-07-23 16:43:56');

-- --------------------------------------------------------

--
-- Table structure for table `members_loan_type`
--

CREATE TABLE `members_loan_type` (
  `id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `loan_type_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `position`
--

CREATE TABLE `position` (
  `id` int(11) NOT NULL,
  `position` text NOT NULL,
  `access_level` int(11) NOT NULL,
  `reg_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `position`
--

INSERT INTO `position` (`id`, `position`, `access_level`, `reg_date`) VALUES
(1, 'president', 5, '2017-10-12'),
(2, 'Accountant', 4, '2017-10-09'),
(3, 'Secretary', 3, '2017-10-18'),
(4, 'Treasurer', 2, '2017-10-27'),
(5, 'member', 1, '2017-10-11');

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `id` int(11) NOT NULL,
  `staff_id` text NOT NULL,
  `trans_date` datetime NOT NULL,
  `trans_type` text NOT NULL,
  `amount` int(11) NOT NULL,
  `narration` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`id`, `staff_id`, `trans_date`, `trans_type`, `amount`, `narration`) VALUES
(1, 'm100', '0000-00-00 00:00:00', '1', 2000, 'Emergency'),
(2, 'm100', '2017-10-17 23:31:49', '1', 3455, 'Medical'),
(3, 'm200', '2017-10-17 23:43:58', '1', 1000, 'broke'),
(4, 'm300', '2017-10-17 23:45:51', '1', 1444, 'check out'),
(5, 'm200', '2017-10-18 00:03:54', '1', 2342, 'Heavy'),
(6, 'm100', '2017-10-18 00:35:19', '1', 8000, 'Savings'),
(7, '0', '2017-10-18 00:36:00', '0', 8000, 'Savings'),
(8, '0', '2017-10-18 00:36:31', '1', 2999, 'Feeding'),
(9, 'm100', '2017-10-18 00:38:25', '0', 8000, 'Family'),
(10, 'm200', '2017-10-18 00:39:42', '0', 8000, 'Family'),
(11, 'm100', '2017-10-18 00:41:14', '0', 23000, 'Salary'),
(12, 'm100', '2017-10-18 17:46:55', '0', 4500, 'Paid Salary'),
(13, '0', '2017-10-18 17:47:24', '1', 2000, 'Emergency'),
(14, '0', '2017-10-18 17:47:24', '1', 2000, 'Emergency'),
(15, 'm200', '2017-10-18 17:48:03', '0', 2300, 'Medical'),
(16, 'm300', '2017-10-19 13:05:28', '0', 30200, 'Emergency'),
(17, '0', '2017-10-19 13:06:12', '1', 10300, 'Medical'),
(18, '0', '2017-10-19 13:06:12', '1', 10300, 'Medical'),
(19, '0', '2017-10-19 13:08:01', '1', 29000, 'Test'),
(20, '0', '2017-10-19 13:09:22', '1', 50100, 'Test'),
(21, '0', '2017-10-19 13:40:48', '1', 34, 'Test'),
(22, '0', '2017-10-19 13:43:16', '1', 350, 'Test'),
(23, '0', '2017-10-19 13:44:20', '1', 23, 'Test'),
(24, '0', '2017-10-19 13:45:54', '1', 67, 'Test'),
(25, '0', '2017-10-19 13:49:11', '1', 340, 'Test'),
(26, '0', '2017-10-19 13:50:20', '1', 367, 'Test'),
(27, '0', '2017-10-19 13:51:28', '1', 239, 'Test'),
(28, '0', '2017-10-19 13:54:02', '1', 12, 'Test'),
(29, '0', '2017-10-19 13:56:06', '1', 75, 'Test'),
(30, '0', '2017-10-19 13:56:47', '1', 4500, 'Test'),
(31, '0', '2017-10-19 13:57:53', '1', 90, 'Test'),
(32, '0', '2017-10-19 13:59:15', '1', 569, 'Test'),
(33, '0', '2017-10-19 14:01:31', '1', 45, 'Test'),
(34, '0', '2017-10-19 14:09:17', '1', 690, 'Test'),
(35, '0', '2017-10-19 14:12:49', '1', 450, 'Test'),
(36, '0', '2017-10-19 14:17:17', '1', 373, 'Test'),
(37, '0', '2017-10-19 14:19:23', '1', 47, 'Test'),
(38, '0', '2017-10-19 14:21:26', '1', 89, 'Emergency'),
(39, '0', '2017-10-19 14:22:47', '0', 200, 'Medical'),
(40, '0', '2017-10-19 14:26:00', '0', 200, 'Medical'),
(41, '0', '2017-10-19 14:26:12', '0', 200, 'Medical'),
(42, '0', '2017-10-19 14:27:51', '0', 200, 'Medical'),
(43, '0', '2017-10-19 14:31:53', '0', 100, 'Education'),
(44, '0', '2017-10-19 14:33:08', '1', 100, 'Test'),
(45, '0', '2017-10-19 14:36:10', '0', 100, 'Emergency'),
(46, '0', '2017-10-19 14:40:39', '0', 200, 'Medical'),
(47, '0', '2017-10-19 14:40:42', '0', 200, 'Medical'),
(48, '0', '2017-10-19 14:41:45', '0', 200, 'Medical'),
(49, '0', '2017-10-19 14:42:54', '0', 300, 'Test'),
(50, '0', '2017-10-19 14:43:41', '0', 300, 'Test'),
(51, '0', '2017-10-19 14:46:36', '0', 300, 'Test'),
(52, '0', '2017-10-19 14:47:44', '0', 200, 'Emergency'),
(53, '0', '2017-10-19 14:52:19', '0', 1000, 'Transport'),
(54, '0', '2017-10-19 14:53:11', '0', 1000, 'Medical'),
(55, '0', '2017-10-19 14:53:49', '1', 2000, 'Emergency'),
(56, '0', '2017-10-19 17:04:09', '1', 40000, 'School'),
(57, '0', '2017-10-19 17:06:07', '1', 200, 'Airtime'),
(58, '0', '2017-10-19 17:07:32', '1', 300, 'Emergency'),
(59, '0', '2017-10-19 17:12:08', '1', 200, 'Emergency'),
(60, '0', '2017-10-19 17:14:33', '1', 200, 'Emergency'),
(61, '0', '2017-10-19 17:20:27', '1', 200, 'Medical'),
(62, '0', '2017-10-19 17:40:51', '1', 300, 'Medical'),
(63, '0', '2017-10-19 17:48:34', '1', 400, 'Education'),
(64, '0', '2017-10-19 17:49:43', '1', 100, 'Transport'),
(65, '0', '2017-10-19 17:51:51', '1', 300, 'Emergency'),
(66, '0', '2017-10-19 19:45:53', '0', 40000, 'Salary'),
(67, '0', '2017-10-19 19:46:56', '1', 200, 'Airtime'),
(68, '0', '2017-10-19 19:53:39', '0', 300, 'Feeding'),
(69, '0', '2017-10-19 19:54:19', '1', 700, 'Airtime'),
(70, '0', '2017-10-19 19:56:00', '1', 600, 'Test'),
(71, '0', '2017-10-19 19:58:35', '0', 23000, 'Gift'),
(72, '0', '2017-10-23 23:58:16', '1', 3000, 'Emergency'),
(73, '0', '2017-10-23 23:58:16', '1', 3000, 'Emergency'),
(74, '0', '2017-10-23 23:59:27', '1', 3000, 'Emergency'),
(75, '0', '2017-10-24 00:25:34', '1', 300, 'Card'),
(76, '0', '2017-10-24 00:26:53', '1', 4000, 'Med'),
(77, '0', '2017-10-24 14:59:21', '0', 2000, 'School'),
(78, '0', '2017-10-24 16:34:53', '0', 4000, 'Salary'),
(79, '0', '2017-10-24 16:38:10', '1', 21000, 'Emergency'),
(80, '0', '2017-11-13 08:58:58', '3', 1240, 'DsiHUB Asaba'),
(81, '0', '2017-11-13 09:00:54', '3', 1000, 'Zenith Bank Asaba'),
(82, 'm100', '2017-11-13 22:41:00', '3', 4000, 'At Science and Tech. Asaba'),
(83, 'm100', '2017-11-13 22:42:16', '3', 200, 'At Asaba Delta State '),
(84, 'm100', '2017-11-13 22:42:47', '3', 300, 'At Asaba Delta State '),
(85, 'm100', '2017-11-27 09:30:28', '3', 56000, 'At Science and Tech. Asaba');

-- --------------------------------------------------------

--
-- Table structure for table `withdraw`
--

CREATE TABLE `withdraw` (
  `id` int(11) NOT NULL,
  `member_id` text NOT NULL,
  `admin_id` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `date_applied` datetime NOT NULL,
  `date_approve` datetime NOT NULL,
  `reason` text NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `withdraw`
--

INSERT INTO `withdraw` (`id`, `member_id`, `admin_id`, `amount`, `date_applied`, `date_approve`, `reason`, `status`) VALUES
(1, 'm100', 0, 21000, '2017-10-24 16:38:10', '0000-00-00 00:00:00', 'Emergency', 0),
(2, 'm100', 0, 300, '2017-10-24 00:25:34', '0000-00-00 00:00:00', 'Card', 0),
(3, 'm200', 0, 300, '2017-10-24 00:25:34', '0000-00-00 00:00:00', 'Card', 0),
(4, 'm100', 0, 300, '2017-10-24 00:25:34', '0000-00-00 00:00:00', 'Card', 0),
(5, 'm100', 0, 300, '2017-10-24 00:25:34', '0000-00-00 00:00:00', 'Card', 0),
(6, 'm200', 0, 300, '2017-10-24 00:25:34', '0000-00-00 00:00:00', 'Card', 0),
(7, '0', 0, 300, '2017-10-24 00:25:34', '0000-00-00 00:00:00', 'Card', 0),
(8, '0', 0, 300, '2017-10-24 00:25:34', '0000-00-00 00:00:00', 'Card', 0),
(9, '0', 0, 300, '2017-10-24 00:25:34', '0000-00-00 00:00:00', 'Card', 0),
(10, '0', 0, 300, '2017-10-24 00:25:34', '0000-00-00 00:00:00', 'Card', 0),
(11, '0', 0, 300, '2017-10-24 00:25:34', '0000-00-00 00:00:00', 'Card', 0),
(12, '0', 0, 300, '2017-10-24 00:25:34', '0000-00-00 00:00:00', 'Card', 0),
(13, '0', 0, 300, '2017-10-24 00:25:34', '0000-00-00 00:00:00', 'Card', 0),
(14, '0', 0, 300, '2017-10-24 00:25:34', '0000-00-00 00:00:00', 'Card', 0),
(15, '0', 0, 300, '2017-10-24 00:25:34', '0000-00-00 00:00:00', 'Card', 0),
(16, '0', 0, 300, '2017-10-24 00:25:34', '0000-00-00 00:00:00', 'Card', 0),
(17, '0', 0, 300, '2017-10-24 00:25:34', '0000-00-00 00:00:00', 'Card', 0),
(18, '0', 0, 300, '2017-10-24 00:25:34', '0000-00-00 00:00:00', 'Card', 0),
(19, '0', 0, 300, '2017-10-24 00:25:34', '0000-00-00 00:00:00', 'Card', 0),
(20, '0', 0, 300, '2017-10-24 00:25:34', '0000-00-00 00:00:00', 'Card', 0),
(21, '0', 0, 300, '2017-10-24 00:25:34', '0000-00-00 00:00:00', 'Card', 0),
(22, '0', 0, 300, '2017-10-24 00:25:34', '0000-00-00 00:00:00', 'Card', 0),
(23, '0', 0, 300, '2017-10-24 00:25:34', '0000-00-00 00:00:00', 'Card', 0),
(24, '0', 0, 300, '2017-10-24 00:25:34', '0000-00-00 00:00:00', 'Card', 0),
(25, '0', 0, 300, '2017-10-24 00:25:34', '0000-00-00 00:00:00', 'Card', 0),
(26, '0', 0, 300, '2017-10-24 00:25:34', '0000-00-00 00:00:00', 'Card', 0),
(27, '0', 0, 300, '2017-10-24 00:25:34', '0000-00-00 00:00:00', 'Card', 0),
(28, '0', 0, 300, '2017-10-24 00:25:34', '0000-00-00 00:00:00', 'Card', 0),
(29, '0', 0, 300, '2017-10-24 00:25:34', '0000-00-00 00:00:00', 'Card', 0),
(30, '0', 0, 300, '2017-10-24 00:25:34', '0000-00-00 00:00:00', 'Card', 0),
(31, '0', 0, 300, '2017-10-24 00:25:34', '0000-00-00 00:00:00', 'Card', 0),
(32, '0', 0, 300, '2017-10-24 00:25:34', '0000-00-00 00:00:00', 'Card', 0),
(33, '0', 0, 300, '2017-10-24 00:25:34', '0000-00-00 00:00:00', 'Card', 0),
(34, '0', 0, 300, '2017-10-24 00:25:34', '0000-00-00 00:00:00', 'Card', 0),
(35, '0', 0, 300, '2017-10-24 00:25:34', '0000-00-00 00:00:00', 'Card', 0),
(36, '0', 0, 300, '2017-10-24 00:25:34', '0000-00-00 00:00:00', 'Card', 0),
(37, '0', 0, 300, '2017-10-24 00:25:34', '0000-00-00 00:00:00', 'Card', 0),
(38, '0', 0, 300, '2017-10-24 00:25:34', '0000-00-00 00:00:00', 'Card', 0),
(39, '0', 0, 300, '2017-10-24 00:25:34', '0000-00-00 00:00:00', 'Card', 0),
(40, 'm100', 0, 2000, '2017-11-13 22:43:23', '0000-00-00 00:00:00', 'rest', 0),
(41, 'm100', 0, 50000, '2017-11-14 17:27:18', '0000-00-00 00:00:00', 'medical', 0),
(42, 'm100', 0, 50000, '2017-11-14 17:31:06', '0000-00-00 00:00:00', 'medical', 0),
(43, 'm100', 0, 90000, '2017-11-14 17:32:23', '0000-00-00 00:00:00', 'medical', 0);

-- --------------------------------------------------------

--
-- Table structure for table `withdrawal_policy`
--

CREATE TABLE `withdrawal_policy` (
  `id` int(11) NOT NULL,
  `no_deposit` text NOT NULL,
  `percentage` int(11) NOT NULL,
  `duration` int(11) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `withdrawal_policy`
--

INSERT INTO `withdrawal_policy` (`id`, `no_deposit`, `percentage`, `duration`, `date`) VALUES
(1, '3', 50, 3, '2017-11-13 21:50:30');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `access_level`
--
ALTER TABLE `access_level`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `adminmessage`
--
ALTER TABLE `adminmessage`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `config`
--
ALTER TABLE `config`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `deposit`
--
ALTER TABLE `deposit`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `loan`
--
ALTER TABLE `loan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `loantype`
--
ALTER TABLE `loantype`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `logged`
--
ALTER TABLE `logged`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `members_loan_type`
--
ALTER TABLE `members_loan_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `position`
--
ALTER TABLE `position`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `withdraw`
--
ALTER TABLE `withdraw`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `withdrawal_policy`
--
ALTER TABLE `withdrawal_policy`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `access_level`
--
ALTER TABLE `access_level`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `adminmessage`
--
ALTER TABLE `adminmessage`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `config`
--
ALTER TABLE `config`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `deposit`
--
ALTER TABLE `deposit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `loan`
--
ALTER TABLE `loan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `loantype`
--
ALTER TABLE `loantype`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `logged`
--
ALTER TABLE `logged`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `members`
--
ALTER TABLE `members`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `members_loan_type`
--
ALTER TABLE `members_loan_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `position`
--
ALTER TABLE `position`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `transaction`
--
ALTER TABLE `transaction`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=86;

--
-- AUTO_INCREMENT for table `withdraw`
--
ALTER TABLE `withdraw`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `withdrawal_policy`
--
ALTER TABLE `withdrawal_policy`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
