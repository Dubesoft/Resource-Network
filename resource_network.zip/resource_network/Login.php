<?php include ("includes/header.php");?>
    <div class="container">
        <div class="row text-center ">
            <div class="col-md-12">
                <br /><br />

                 <br />
            </div>
        </div>
         <div class="row ">

                  <div class="col-md-6 col-md-offset-3 col-sm-6 col-sm-offset-3 col-xs-10 col-xs-offset-1">
                        <div class="panel panel-default">
                            <div class="panel-heading" style="background-color: #cdc8c4; padding-top: 30px;padding-left: 10px">

                                    <center><strong><h3 style="color:#1a446b;font-weight: 600; text-align: left" >MEMBER LOGIN</h3></strong></center>
                            </div>
                            <div class="panel-body">
                                <form role="form" action="loginprocess.php" method="post">
                                       <br />
                                     <div class="form-group input-group">
                                            <span class="input-group-addon"><span class="input-icon input-icon-user"></span><span class="input-text">Staff id</span></span>
                                            <input type="text" class="form-control"  name="staff_id" id="inputError2"/>
                                        </div>
                                                                              <div class="form-group input-group">
                                            <span class="input-group-addon"><span class="input-icon input-icon-password"></span><span class="input-text">Password</span></span>
                                            <input type="password" class="form-control transparent"   name="password"/>
                                        </div>
                                    <div class="form-group">
                                            <label class="checkbox-inline">
                                                <input type="checkbox" /> Remember me
                                            </label>
                                            <span class="pull-right">
                                                   <a href="#" >Forget password ? </a>
                                            </span>
                                        </div>

                                       <input type="submit"   class="btn btn-default pull-right" value="Log In" name="login">

                                    <hr />
                                    Not register ? <a href="register.php" >Sign Up</a>


                                    </form>


                            </div>

                        </div>
                    </div>


        </div>
    </div>


     <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>

</body>
</html>
<?php include ("includes/footer.php");?>