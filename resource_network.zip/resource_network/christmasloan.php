<?php include("includes/header.php");?>

			<!-- site content -->
			<div id="main">
				<!--Breadcrumb Section Start Here-->
				<div class="breadcrumb-section">
					<div class="container">
						<div class="row">
							<div class="col-xs-12">
								<h1>Causes</h1>
								<ul class="breadcrumb">
									<li>
										<a href="index.html">Home</a>
									</li>
									<li class="active">
										Causes
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
				<!--Breadcrumb Section End Here-->

				<div class="cause-page content-wrapper" id="page-info">
					<div class="container">

						<!-- our causes detail-->

						<div class="anim-section">
							<div class="row">
								<div class="col-xs-12 col-sm-9 left-block">

									<div class="article-list-large causes-description progressbar">

										<div class="anim-section">
											
												
													<figure>
													<img src="assets/img/detail-med-01.jpg" alt="">
													</figure>
											
											<div class="progress">
												<div class="progress-bar" role="progressbar" aria-valuenow="72" aria-valuemin="0" aria-valuemax="100">
													<span class="progress-value">72% </span>
												</div>
											</div>

											<div class="heading-sec text-left">
												<h3 class="h4">Help African children to get shelter</h3>
												<span class="date-desc">06 august, 2014 Africa, Child care</span>
											</div>
											<div class="row">
												<div class="col-xs-12">

													<span class="donation">Donation : <span class="value">$78,354 <small>/ $1,26,500</small></span></span>
													<a data-toggle="modal" href="external.html" data-target=".donate-form" class="btn btn-default pull-right">DONATE NOW</a>
												</div>
											</div>

											<div class="detail-description">

												<p class="detail-summary">
												Being homeless is perhaps hardest on the children. They need to feel safe and secure, so that they can concentrate in school. In addition to this, they need exercise, recreation and playtime. You can donate to help African children to help them get their shelter. In short, homeless children need everything that we take for granted but they need it every day.
												</p>
												<p>
													You can offer any kind of support to homeless children by providing therapeutic support services with the goal of improving their emotional and behavioral well being. This helps the children’s progression towards increased financial stability.
												</p>

												<p>
													Homeless children need a wide range of support services to address their mental and physical health. They often need addiction treatment, psychological counseling, job training, childcare and eventual job placement help. Providing an overall growth to homeless children is not an easy task and the job cannot be fulfilled without your support. Hence, help us raise the standards of these poverty stricken children in any of the manners possible. We attempt to provide shelter, security and a bright future to the children in the following manner. 
												</p>

												<ul class="list-trangled">
													<li>
														Fulfillment of primary necessities that includes food, clothing and shelter
													</li>
														<li>
														Medical care to the children who have a poor health or to those who require special medical attention
													</li>
													<li>
														Education opportunities to homeless children so that they can have a bright future ahead
													</li>
													<li>
														Security to their future by providing them training on sports and other curriculum activities
													</li>
												</ul>

												<a data-toggle="modal" href="external.html" data-target=".donate-form" class="btn btn-default">DONATE NOW</a>
											</div>
											<!--step donation-->

											<div class="step-donation sec-step-med causes-details-step anim-section">

												<header class="page-header section-header">
													<h2>How you can Donate, <strong>Easy Steps</strong></h2>
												</header>

												<div class="col-xs-12 text-center">

													<div class="cols-xs-12 col-sm-4">
														<div class="sec-step-desc">
															<span class="number-count">1</span>
															<h4 class="normal-text">Select how much you want to Donate</h4>
															<p>
																Provide us your preference by denoting how much you can donate
															</p>
														</div>

													</div>

													<div class="cols-xs-12 col-sm-4">
														<div class="sec-step-desc">
															<span class="number-count">2</span>
															<h4 class="normal-text"> Fill The Simple Form</h4>
															<p>
																Fill up a simple form to let us know a bit about you and donation reason
															</p>
														</div>

													</div>

													<div class="cols-xs-12 col-sm-4">
														<div class="sec-step-desc">
															<span class="number-count">3</span>
															<h4 class="normal-text">Feel proud on helping out</h4>
															<p>
																Fill the form, send it to us and feel proud to be a part of our donation campaign.
															</p>
														</div>

													</div>
												</div>
												<!--step donation-->

											</div>
										</div>

									</div>

							

										<div class="row article-list progressbar">
											<header class="col-xs-12 block-title">
												<h3>Related Causes</h3>
											</header>

											<div class="col-xs-12 col-sm-4 zoom anim-section">

												<a href="#" class="img-thumb">
													<figure>
													<img src="assets/img/img-slide-01.jpg" alt="">
													</figure>
													</a>
												<div class="progress">
													<div class="progress-bar" role="progressbar" aria-valuenow="72" aria-valuemin="0" aria-valuemax="100">
														<span class="progress-value">72% </span>
													</div>
												</div>
												<span class="donation">Donation : <span class="value">$78,354 <small>/ $1,26,500</small></span></span>
												<p>
													
										Improve living style of people, who are affected by several health issues & poverty and unable to come out this situation. 
										
												</p>
												<a data-toggle="modal" href="external.html" data-target=".donate-form" class="btn btn-default">DONATE NOW</a>

											</div>
											<div class="col-xs-12 col-sm-4 zoom anim-section">

												<a href="#" class="img-thumb">
													<figure>
													<img src="assets/img/img-slide-02.jpg" alt="">
													</figure>
													</a>
												<div class="progress">
													<div class="progress-bar" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100">
														<span class="progress-value">60% </span>
													</div>
												</div>
												<span class="donation">Donation : <span class="value">$78,354 <small>/ $1,26,500</small></span></span>
												<p>
													
											Give an opportunity to girls to become educated, so that, they can stand with boys and get a self exposure worldwide.  
										
												</p>
												<a data-toggle="modal" href="external.html" data-target=".donate-form" class="btn btn-default">DONATE NOW</a>
											</div>
											<div class="col-xs-12 col-sm-4 zoom anim-section">

												<a href="#" class="img-thumb">
													<figure>
													<img src="assets/img/img-slide-03.jpg" alt="">
													</figure>
													</a>
												<div class="progress">
													<div class="progress-bar" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100">
														<span class="progress-value">80% </span>
													</div>
												</div>
												<span class="donation">Donation : <span class="value">$78,354 <small>/ $1,26,500</small></span></span>
												<p>
													
											You can offer your support by sending vegetables that we can further send to these children in Africa
										
												</p>
												<a data-toggle="modal" href="external.html" data-target=".donate-form" class="btn btn-default">DONATE NOW</a>
											</div>

										</div>
								

								</div>

								<div class="col-xs-12 col-sm-3 left-block ">
									<aside class="media">
										<h3 class="space-top">Recent</h3>
										<ul>
											<li>
												<a href="#" class="pull-left">
													<figure>
													<img src="assets/img/aside-img-01.jpg" alt="" />
													</figure>
													</a>
												<div class="media-body">
													<p>
														<a href="#">
														Fusce mauris enim faci lisis sceler
														</a>
													</p>
													<span> 23, March’14 </span>
												</div>
											</li>

											<li>
												<a href="#" class="pull-left">
													<figure>
													<img src="assets/img/aside-img-02.jpg" alt="" />
													</figure>
													</a>
												<div class="media-body">
													<p>
														<a href="#">
														Mauris enim faci lisis sceler isque non
														</a>
													</p>
													<span> 23, March’14 </span>
												</div>
											</li>

											<li>
												<a href="#" class="pull-left">
													<figure>
													<img src="assets/img/aside-img-03.jpg" alt="" />
													</figure>
													</a>
												<div class="media-body">
													<p>
														<a href="#">
														Enim faci lisis sceler isque nonmauris
														</a>
													</p>
													<span> 23, March’14 </span>
												</div>
											</li>
										</ul>

									</aside>

									<!-- Archives   -->
									<aside class="media">
										<h3>Archives</h3>
										<ul class="archives">
											<li>
												<a href="#">
												March 2013 <span class="pull-right">(12)</span>
												</a>
											</li>
											<li>
												<a href="#">
												February 2013 <span class="pull-right">(12)</span>
												</a>
											</li>
											<li><a href="#">
												January 2013 <span class="pull-right">(43)</span>
											</a>
											</li>
											<li><a href="#">
												December 2012 <span class="pull-right">(12)</span>
											</a>
											</li>
											<li>
												<a href="#">
												November 2012 <span class="pull-right">(32)</span>
												</a>
											</li>
										</ul>
									</aside>

									<!-- Categories  -->
									<aside class="media">
										<h3>Categories</h3>
										<ul class="archives">
											<li>
												<a href="#">
												Integer <span class="pull-right">(20)</span>
												</a>
											</li>
											<li><a href="#">
												Accumsan <span class="pull-right">(18)</span>
											</a>
											</li>
											<li><a href="#">
												Fermentum <span class="pull-right">(15)</span>
											</a>
											</li>
											<li>
												<a href="#">
												Vehicula <span class="pull-right">(12)</span>
												</a>
											</li>
											<li>
												<a href="#">
												Magna <span class="pull-right">(30)</span>
												</a>
											</li>

										</ul>
									</aside>

									<!-- Text Widget -->
									<div class="text-widget">
										<h3>Text Widget</h3>
										<p>
											Placerat vel augue vitae aliquam tinciuntool sed hendrerit diam in mattis ollis don ec  tincidunt magna nullam hedrerit pellen tesque pelle.
										</p>
									</div>

								</div>
							</div>

						</div>

						<!-- our causes detail-->

					</div>

				</div>

			</div>
			<!-- site content ends -->

			<?php include ("includes/footer.php");?>