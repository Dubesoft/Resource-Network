<?php include ("includes/header.php");?>
    <div class="container">
        <div class="row text-center ">
            <div class="col-md-12">
                <br /><br />

                <br />
            </div>
        </div>
        <div class="row ">

            <div class="col-md-6 col-md-offset-3 col-sm-6 col-sm-offset-3 col-xs-10 col-xs-offset-1">
                <div class="panel panel-default">
                    <div class="panel-heading" style="background-color: #cdc8c4; padding-top: 30px;padding-left: 10px">

                        <center><strong><h3 style="color:#1a446b;font-weight: 600; text-align: left" >REGISTRATION  FORM</h3></strong></center>
                    </div>
                    <div class="panel-body">
                        <form role="form" action="process_usersignup.php" method="post">
                            <br />
                            <div class="form-group input-group">
                                <span class="input-group-addon"><span class="input-icon input-icon-user"></span><span class="input-text">Staff id</span></span>
                                <input type="text" class="form-control"  name="staff_id" id="inputError2"/>
                            </div>
                            <div class="form-group input-group">
                                <span class="input-group-addon"><span class="input-icon input-icon-user"></span><span class="input-text">Firstname</span></span>
                                <input type="text" class="form-control"  name="firstname" id="inputError2"/>
                            </div>
                            <div class="form-group input-group">
                                <span class="input-group-addon"><span class="input-icon input-icon-user"></span><span class="input-text">Lastname</span></span>
                                <input type="text" class="form-control"  name="lastname" id="inputError2"/>
                            </div>
                            <div class="form-group input-group">
                                <span class="input-group-addon"><span class="input-icon input-icon-user"></span><span class="input-text">Email</span></span>
                                <input type="text" class="form-control"  name="Email" id="inputError2"/>
                            </div>
                            <div class="form-group input-group">
                                <span class="input-group-addon"><span class="input-icon input-icon-password"></span><span class="input-text">Password</span></span>
                                <input type="password" class="form-control transparent"   name="password"/>
                            </div>
                            <div class="form-group input-group">
                                <span class="input-group-addon"><span class="input-icon input-icon-user"></span><span class="input-text">Retype Password</span></span>
                                <input type="password" class="form-control"  name="repass" id="inputError2"/>
                            </div>

                            <input type="submit"   class="btn btn-default pull-right" value="Register" name="submit">

                            <hr />
                            Already registerd ? <a href="login.php" >Login</a>


                        </form>
                    </div>

                </div>
            </div>


        </div>
    </div>


    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
    <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>

    </body>
    </html>
<?php include ("includes/footer.php");?>