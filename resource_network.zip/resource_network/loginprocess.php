

<?php
include ("Connect.php");
session_start();
	include ("includes/connect.php");
	
        if(isset($_POST['login'])){
	 	$staff_id = $_POST['staff_id'];
                $password = $_POST['password'];
        //echo 'Your occupation: ' . $proffession;
		
		
		//$uname = trim($uname);
                //$password = trim($password);
		
                //$uname= htmlspecialchars($uname);
		//$password = htmlspecialchars($password);
		
                
                //$uname = stripslashes($unmae);
                //$password = stripslashes($password);
                
		
	$epassword = md5($password);
        /*
        $_SESSION['uname'] = null;
        $psql="SELECT * FROM photos  WHERE uname = '$uname'" ;
 $presult=mysql_query($psql) or die(mysql_error());
       	while ( $row = mysql_fetch_array($presult) ) {
		
            
            $_SESSION['uname']= $row['uname'];
        }
        
         * 
         */
        echo $staff_id;
        echo $password;
function mysql_prep($string){
     global $connection;
     
     $escaped_string = mysqli_real_escape_string($connection, $string);
     return $escaped_string;
 }
        
        
       // function confirm_query($result_set){
     //if (!$result_set){
       //  die("Database query failed.");
     //}
 //}        
        
        
$query = "SELECT * ";
$query .= "FROM members ";
$query .= "WHERE staff_id = '$staff_id' ";
$query .= "AND password = '$epassword' ";
$query .= "AND status = '1' ";
$result = mysqli_query($connection, $query);
//confirm_query($result);


//confirm_query($result);
 
       	while ( $row = mysqli_fetch_array($result) ) {
		
            
            $_SESSION['mid'] = $row['id'];
            //$_SESSION['admin_id']= $row['admin_id'];
            //$_SESSION['password']= $row['password'];
            
	/*
			//echo $username;
			//echo $password;
		//$_SESSION['id']= $row['reg'];
		$_SESSION['status'] =$row['status'];
		$_SESSION['email']= $row['email'];
			$_SESSION['id']= $row['id'];
			$_SESSION['name']= $row['name'];
			$allow= $row['allow'];
		//$date = date('Y-m-d H:i:s');
		//$time = date("h:i:sa");
		
		
		/*while ($allow == 0){
			header ("location: dashboard3.php");
              quit();

		}
		*/
			
header ("location: member/dashboard.php");
die();
        }
		}else{
                  header ("location: member/dashboard");  
                }

		?>	

   <script type="text/javascript">
alert(" Ensure you have been approved by the admin");

window.location="login.php";
</script>
<?php

die();

   
			

?>
