<?php
session_start();
include ("includes/connect.php");
//$userid = $_SESSION['id'];
//$puname = $_SESSION['uname'];
$aid = $_GET['aid'];

//if(isset($_POST['submit'])){

    //$fname = $_POST ['fname'];
    //$lname = $_POST ['lname'];
    //$email = $_POST ['email'];
    //$password = $_POST ['password'];
    
    //echo "I am showing";
    
    
 







    $query = "UPDATE admin SET status='0' WHERE id = '$aid'";
	$result= mysqli_query($connection, $query) or die(mysqli_error());



if ($result){
	
	 ?>
   <script type="text/javascript">
alert("admin de-activation successfully");

window.location="viewadmins.php";
</script>
<?php

die();

   
   }else{
       ?>
 <script type="text/javascript">
alert("admin de-activtion failed");

window.location="viewadmins.php";
</script>
<?php
   }
//}
?> 
