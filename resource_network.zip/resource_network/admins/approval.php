<?php include ("assets/header.php"); ?>
<link rel="stylesheet" href="../css/style.css">
<?php include ("assets/Navigation.php"); ?>

<?php $member_id = $_SESSION['mid'];?>
      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        

        
        
        
        
        
        
        
        
        
        
        
        
        
        
        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Pending Withdrawal Approval</h3>
                </div><!-- /.box-header -->
                <div class="box-body">
                    <table id="example2" class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <th>id</th>
                                <th>First Name</th>
                                <th>Last Name</th>
                                <th>Email</th>
                                <th>Amount</th>
                                <th>Reason</th>
                                <th>Picture</th>
                                <!--<th>status</th>-->
                                <th>Date</th>
                                <th>Control</th>
                                <th>Control</th>
                            </tr>
                        </thead>
                        <tbody>                      
<?php
$query = "SELECT * ";
$query .= "FROM members, withdraw ";
$query .= "WHERE members.id = withdraw.id AND withdraw.status = '0' ";         
          $index = 0;
 $result = mysqli_query($connection, $query);
 $counter=1;
       	while ( $row = mysqli_fetch_array($result)) {
		//$row_count =  mysql_num_rows($result);
                $wid =$row['id'];
		//$_SESSION['fname'] =$row['fname'];
                //$first = $_SESSION['fname'];
               // $_SESSION['lname'] =$row['lname'];
		$amount= $row['amount'];
                $_SESSION['date_applied']= $row['date_applied'];
                $_SESSION['reason']= $row['reason'];
                $picture = $row['picture'];
                $imagepath = "../photo/".$picture;
                
                ?>
                <tr>
                        <td><?php echo $counter;?></td>
                        <td><?php echo $row['firstname'];?></td>
                        <td><?php echo $row['lastname'];?></td>
                        <td><?php echo $row['email']?></td>
                        <td><?php echo $row['amount']?></td>
                        <td><?php echo $row['reason']?></td>
                        <td><img src="<?php echo $imagepath; ?>" alt="user image" height="10" class="img-rounded"></td>
                        <!--<td><?php echo $row['status']?></td>-->
                        <td><?php echo $row['date_applied']?></td>
                        <td><a href="process_approval.php?wid=<?php echo $wid; ?>&amount=<?php echo $amount; ?>" onsubmit="if(!confirm('Are you sure you want to make changes to this record?')){return false;}" class="btn btn-success  col-lg-offset-2">Approve</a></td>
                        <td><a href="process_decline.php?wid=<?php echo $wid; ?>" onsubmit="if(!confirm('Are you sure you want to make changes to this record?')){return false;}" class="btn btn-danger col-lg-offset-2">Decline</a></td>
                      </tr>
                
                
                <?php
                $counter++;
        }
        ?>
          </tbody>
                       
                    </table>     
                </div>
                </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
          
          
          <div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Pending Loan Approval</h3>
                </div><!-- /.box-header -->
                <div class="box-body">
                    <table id="example2" class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <th>id</th>
                                <th>First Name</th>
                                <th>Last Name</th>
                                <th>Email</th>
                                <th>Amount</th>
                                <th>Reason</th>
                                <th>Picture</th>
                                <!--<th>status</th>-->
                                <th>Date</th>
                                <th>Control</th>
                                <th>Control</th>
                            </tr>
                        </thead>
                        <tbody>                      
<?php
$query = "SELECT * ";
$query .= "FROM members, loan ";
$query .= "WHERE members.id = loan.id AND loan.status = '0' ";         
$index = 0;
 $result = mysqli_query($connection, $query);
 $counter=1;
       	while ( $row = mysqli_fetch_array($result) ) {
		//$row_count =  mysql_num_rows($result);
                $lid =$row['id'];
		//$_SESSION['fname'] =$row['fname'];
                //$first = $_SESSION['fname'];
               // $_SESSION['lname'] =$row['lname'];
		//$amount= $row['amount'];
                $_SESSION['date_applied']= $row['applied_date'];
                $_SESSION['reason']= $row['reason'];
                $picture = $row['picture'];
                $imagepath = "../photo/".$picture;
                
                ?>
                <tr>
                        <td><?php echo $counter;?></td>
                        <td><?php echo $row['firstname'];?></td>
                        <td><?php echo $row['lastname'];?></td>
                        <td><?php echo $row['email']?></td>
                        <td><?php echo $row['amount']?></td>
                        <td><?php echo $row['reason']?></td>
                        <td><img src="<?php echo $imagepath; ?>" alt="user image" height="50" class="img-rounded"></td>
                        <!--<td><?php echo $row['status']?></td>-->
                        <td><?php echo $row['applied_date']?></td>
                        <td><a href="process_loan_approval.php?lid=<?php echo $lid;?>" onsubmit="if(!confirm('Are you sure you want to make changes to this record?')){return false;}" class="btn btn-success  col-lg-offset-2">Approve</a></td>
                        <td><a href="process_decline.php?lid=<?php echo $lid; ?>" onsubmit="if(!confirm('Are you sure you want to make changes to this record?')){return false;}" class="btn btn-danger col-lg-offset-2">Decline</a></td>
                      </tr>
                
                
                <?php
                $counter++;
        }
        ?>
          </tbody>
                       
                    </table>     
                </div>
                </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
              <!-- Form Element sizes -->
              
              

      <?php include ("assets/footer.php"); ?>