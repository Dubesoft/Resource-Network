<?php 
session_start();
include ("includes/connect.php");

$w_id = $_GET['wid'];
//echo $memberid;


    $wquery = "UPDATE withdraw SET status = 3 WHERE id = '$w_id'";
    $wresult = mysqli_query($connection, $wquery);
if($wresult){
        //$_SESSION["message"] = "Transaction Successful!";
        //header ("location: transaction.php");
        ?>
<script type="text/javascript">
    alert("Withdrawal Decline Successful!");
    window.location="pending_withdrawal.php";
</script>
<?php
    }else{
        //$_SESSION["message"] = "Transaction failed!";
       // header ("location: transaction.php");
        ?>
<script type="text/javascript">
    alert("Withdrawal Decline failed!");
    window.location="pending_withdrawal.php";
</script>
<?php
       
    }
        
        
?>

