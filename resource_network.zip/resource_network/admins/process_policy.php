<?php 
session_start();
include ("includes/connect.php");


    $loan_name = $_POST ['loan_name'];
    $psr = $_POST ['psr'];
    $months_duration = $_POST ['months_duration'];
    
    
    
    //$_SESSION["amount"] = $amount;
    //$_SESSION["trans_type"] = $trans_type;
    //$_SESSION["reason"] = $reason;
    //header ("location: transaction.php");

  
    $query = "INSERT INTO policy (";
    $query .= " loan_name, psr, duration, date";
    $query .= ") VALUES (";
    $query .=" '{$loan_name}', {$psr}, {$months_duration}, NOW()";
    $query .= ")";
    $result = mysqli_query($connection, $query); 
    if($result){
          //$_SESSION["message"] = "Transaction Successful!";
        //header ("location: transaction.php");
        ?>
<script type="text/javascript">
    alert("Loan Policy Setup Successful!");
    window.location="policy.php";
</script>
<?php
    }else{
        //$_SESSION["message"] = "Transaction failed!";
       // header ("location: transaction.php");
        ?>
<script type="text/javascript">
    alert("Loan Policy Setup failed!");
    window.location="policy.php";
</script>
<?php
    }
    
    
?>