<?php include("includes/header.php"); ?>
<?php include("includes/navigation.php"); ?>
<?php $a_id = $_GET['aid']; ?>

<?php
$query = "SELECT * ";
$query .= "FROM adminmessage ";
$query .= "WHERE id = '$a_id' ";         
          $index = 0;
 $result = mysqli_query($connection, $query);
 $counter=1;
       	while ( $row = mysqli_fetch_array($result) ) {
		//$row_count =  mysql_num_rows($result);
                $name =$row['name'];
                $subject =$row['subject'];
                $message =$row['message'];
		
        }
                 
                ?>

        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2 style="color: #232347" class="col-sm-offset-4">Read Message</h2>
        <hr>
        <br>
                    </div>
                </div>
                 <!-- /. ROW  -->
                
                                 

                   <!-- /. ROW  -->
            <div class="row">
                <div class="col-md-12 col-sm-8">
                    <div class="panel panel-warning">
                        <div class="panel-heading">
                            Enter your Message Below
                        </div>
                        <form action="process_compose_message.php" method="post">
                            <div class="panel-body">
                                <input type="text" class="form-control transparent" placeholder="Name"  name="name" readonly="" value="Name: <?php echo $name; ?>"/>                   
                         </div>
                        <div class="panel-body">
                            <input type="text" class="form-control transparent" placeholder="subject"  name="subject" readonly="" value="Subject: <?php echo $subject; ?>"/>                   
                         </div>
                        <div class="panel-body">
                            <p><textarea name="msg" rows="7" cols="100" class="form-control" placeholder="Message"  readonly="" style="resize: none;">Message: <?php echo $message; ?></textarea></p>
                        </div>
                        <div class="panel-footer">
                           
                        </div>
                        </form>
                    </div>
                </div>
                
                
            </div>
                   <?php include("includes/footer.php"); ?>