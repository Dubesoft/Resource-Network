<?php 
session_start();
include ("connect.php");


    $amount = $_POST ['amount'];
    $trans_type = $_POST ['trans_type'];
    $reason = $_POST ['reason'];
    
    
    //$_SESSION["amount"] = $amount;
    $_SESSION["trans_type"] = $trans_type;
    //$_SESSION["reason"] = $reason;
    //header ("location: transaction.php");

    
    $query = "INSERT INTO transaction (";
    $query .= " trans_date, trans_type, amount, narration";
    $query .= ") VALUES (";
    $query .=" NOW(), {$trans_type}, {$amount}, '{$reason}'";
    $query .= ")";
    
    
    $tresult = mysqli_query($connection, $query);
    /*
    if($result){
        $_SESSION["message"] = "Transaction Successful!";
        header ("location: transaction.php");
    }else{
        $_SESSION["message"] = "Transaction failed!";
        header ("location: transaction.php");
        echo "The content is: " . $query;
    }
    
     * 
     */
     
    if($trans_type == "1"){
        $tquery = "INSERT INTO withdraw (";
    $tquery .= " date_applied, status, amount, reason";
    $tquery .= ") VALUES (";
    $tquery .=" NOW(), 0, {$amount}, '{$reason}'";
    $tquery .= ")";
    
   
    $wresult = mysqli_query($connection, $query);
    if($wresult){
        $_SESSION["message"] = "Transaction Successful!";
        header ("location: transaction.php");
    }else{
        $_SESSION["message"] = "Transaction failed!";
        header ("location: transaction.php");
        echo "The content is: " . $query;
    }
     
    }
     header ("location: transaction.php");
if($tresult){
        //$_SESSION["message"] = "Transaction Successful!";
        //header ("location: transaction.php");
        ?>
<script type="text/javascript">
    alert("Transaction Successful!");
    window.location="transaction.php";
</script>
<?php
    }else{
        //$_SESSION["message"] = "Transaction failed!";
       // header ("location: transaction.php");
        ?>
<script type="text/javascript">
    alert("Transaction failed!");
    window.location="transaction.php";
</script>
<?php
    }
     
    //}
     //header ("location: transaction.php");
?>