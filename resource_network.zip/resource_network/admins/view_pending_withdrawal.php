<?php 
include ("includes/header.php");
include ("includes/navigation.php");
$wid = $_GET['wid'];
//$member_id = $_SESSION['mid'];
//$id= $_GET[id];
//echo $memberid;


$query = "SELECT * ";
$query .= "FROM members, withdraw ";
$query .= "WHERE members.staff_id = withdraw.member_id AND members.staff_id = '$wid' ";          
$index = 0;
 $result = mysqli_query($connection, $query);
       	while ( $row = mysqli_fetch_array($result) ) {

		$members_count =  mysqli_num_rows($result);
                $picture = $row['picture'];
                $imagepath = "photo/".$picture;
                $fname = $row['firstname'];
                $lname = $row['lastname'];
                $email = $row['email'];
                $staff_id = $row['staff_id'];
                $gender = $row['gender'];
                //$position = $row['position'];
                $phone = $row['phonenumber'];
                //$savedbalance = $row['savedbalance'];
                $date = $row['date'];
        }
        
       
   ?>
       <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                
                
                               <!--  Modals-->
                    
                               <form role="form" action="process_editadmin.php" method="post" enctype="multipart/form-data" onsubmit="if(!confirm('Are you sure you want to make changes to this record?')){return false;}">
                                                <h2 class="col-sm-offset-5" style="color: #232347">Withdrawal History</h2>
                     <hr>
                     <br>
                                                
                                    <div class="container-fluid"><img src="<?php echo $imagepath; ?>" alt="user image" height="150" class="col-lg-offset-5 img-rounded"></div>
                                    <h4>Photo Upload</h4>
                                    <input type="hidden" name="MAX_FILE_SIZE" value="1000000">
                                        <p><input type="file" name="file" class="btn btn-default"></p>
                                        <input type="submit" class="btn btn-default" value="Upload Picture" name="upload">
                             
<br>
<br>

                            <div class="row">
        					
				<div class="col-md-6 col-sm-6 col-xs-12">
                                    <h4 class="sub-title" style="color: #232347">YOUR PERSONAL DETAILS</h4>
                                         <div class="form-group input-group">
                                            <span class="input-group-addon"><span class="input-icon input-icon-user"></span><span class="input-text">Member id</span></span>
                                            <input type="text" class="form-control transparent" placeholder="Member id"  name="admin_id" value="<?php echo $staff_id;?>"/>
                                                
                                        </div>
                                        <div class="form-group input-group">
                                            <span class="input-group-addon"><span class="input-icon input-icon-user"></span><span class="input-text">First Name</span></span>
                                            <input type="text" class="form-control transparent" placeholder="First Name"  name="fname" value="<?php echo $fname;?>"/>
                                                
                                        </div>
                                        <div class="form-group input-group">
                                            <span class="input-group-addon"><span class="input-icon input-icon-user"></span><span class="input-text">Last Name</span></span>
                                            <input type="text" class="form-control" placeholder="Last Name"  name="lname" value="<?php echo $lname;?>"/>
           
                                        </div>
                                        <div class="form-group input-group">
                                                                                 <span class="input-group-addon"><span class="input-icon input-icon-email"></span><span class="input-text">Email</span></span>
                                            <input type="text" class="form-control" placeholder="Email" name="email"  value="<?php echo $email;?>"/>
                                                
                                        </div>

                                     <div class="form-group input-group">
                                            <span class="input-group-addon"><span class="input-icon input-icon-user"></span><span class="input-text">Password</span></span>
                                            <input type="password" class="form-control" placeholder="Password" name="password"/>  
                                        </div>
                                        
                                        <div class="form-group input-group">
                                            <span class="input-group-addon"><span class="input-icon input-icon-email"></span><span class="input-text">Phone Number</span></span>
                                            <input type="text" class="form-control" placeholder="Phone Number" name="phone"  value="<?php echo $phone;?>"/>
                                        </div>
                                       
                                        <div class="form-group input-group">                                        
                                                <select name="gender" class="chosen-select form-control">
                                                    <option>Gender</option>
                                                    <option value="male">Male</option>
                                                    <option value="female">Female</option>
                                                </select>
                                            </div>
                                        
                                        <div class="form-group input-group">
                                            <span class="input-group-addon"><span class="input-icon input-icon-email"></span><span class="input-text">Date</span></span>
                                            <input type="text" class="form-control" placeholder="Date" name="date"  value="<?php echo date('d-m-Y', strtotime($date));?>"/>
                                        </div>
                                         
                                </div>
                                
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <h4 class="sub-title" style="color: #232347">WITHDRAWAL DETAILS</h4><br>
                                         <div class="form-group input-group"> 
                                    <?php
                                    //echo $staff_id;
                                        $query = "SELECT * ";
                                        $query .= "FROM transaction ";
                                        $query .= "WHERE staff_id = '$staff_id' AND trans_type = '1'";          
                                        $counter = 1;
                                         $tresult = mysqli_query($connection, $query);
                                                while ( $row = mysqli_fetch_array($tresult) ) {

                                                        $trans_count =  mysqli_num_rows($result);
                                                        echo "<p style='text-align: left'>" . "Transaction " . $counter . "<br>";
                                                        echo "Applied date: " . date('d-m-Y', strtotime($row['trans_date'])) . "<br>";
                                                        echo "Amount: " . "&#8358 ".number_format($row['amount'], 2) . "<br>";
                                                        echo "Reason: " . $row['narration'] . "</p>";
                                                        ?>
                                             <!--<button class="btn btn-primary btn-md btn-md col-sm-offset-2">view</button>-->
                                             <?php
                                             echo "<br>";
                                             $counter++;
                                             }
                                    ?>
</div>
                                         
                                </div>
                            </div>
<br>
<br>
<br>


                                       
          </form>
                                 
                     <!-- End Modals-->
                
                
                            </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->

<?php include ("includes/footer.php"); ?>

         
         
 