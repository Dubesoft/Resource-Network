<?php
session_start();
//require 'phpmailer/PHPMailerAutoload.php';

//$validatcaptcha= $_SESSION["code"];
include("includes/connect.php");
//if(isset($_POST['submit'])){


    $admin_id = $_POST ['admin_id'];
    $fname = $_POST ['fname'];
    $lname = $_POST ['lname'];
    
    $email = $_POST ['email'];
    
    
    $password = $_POST ['password'];
    $repass = $_POST ['repass'];
    //$picture = $_FILES['file']['name'];
    //$size = $_POST ['MAX_FILE_SIZE'];
    //$file = $_POST ['file_upload'];
    //$caption = $_POST ['caption'];
/*
$file = $_FILES['file']['name'];
$file_loc = $_FILES['file']['tmp_name'];
$file_size = $_FILES['file']['size'];
$file_type = $_FILES['file']['type'];

$folder ="photo/";
$new_size =  $file_size/1024;
$new_file_name = strtolower($file);
$final_file = str_replace(' ', '-', $new_file_name);

move_uploaded_file($file_loc, $folder.$final_file);
// $psql="INSERT INTO photos set filename= '$final_file', type='$file_type',  size= '$new_size', caption= '$caption', uname= '$uname'"; 

       
//$presult=mysql_query($psql) or die(mysql_error());
    
 * 
 */




    
    //$pnumber = $_POST ['pnumber'];
    
    
    
   // echo $_POST ['password'];
//$name = mysql_real_escape_string($_POST['name']);
//$email = mysql_real_escape_string($_POST['email']);
//$pnumber = mysql_real_escape_string($_POST['pnumber']);


	
	
	if( strlen($password) < 6  )
   { ?>
   <script type="text/javascript">
alert("Passwords must be greater than 6 characters.");
window.location="createadmins.php";
</script>
<?php
die();

   }
   
	
	if( $password !=$repass  )
   { ?>
   <script type="text/javascript">
alert("Passwords are not identical.");
window.location="createadmins.php"";
</script>
<?php
die();

   }
   
  	
	$query = "SELECT * ";
$query .= "FROM admin ";
$query .= "WHERE email = '$email' ";         
          //$index = 0;
 $mresult = mysqli_query($connection, $query);

 if(mysqli_num_rows($mresult)> 0)
   {
		
	
	?>
	<script type="text/javascript">
alert("Email address has already been used.");
window.location="createadmins.php"";
</script>
<?php
		
header("Location: createadmins.php"); 
die();
			}
		
	
                        
                        
$epassword = md5($password);
    $query = "INSERT INTO admin (";
    $query .= " admin_id, firstname, lastname, password, email, status, date";
    $query .= ") VALUES (";
    $query .=" '{$admin_id}', '{$fname}', '{$lname}', '{$epassword}', '{$email}', 1, NOW()";
    $query .= ")";
    
    
    $mresult = mysqli_query($connection, $query);

       		//if ($presult){ 
                    
                //}
   
       		if ($mresult){ 
			
			
			$to      = $email; // Send email to our user
$subject = 'Signup | Verification on InsuredHelp.org'; // Give the email a subject 
$message = '
 
Thanks for signing up on InsuredHelp.org!
Your account has been created, you can login with the following credentials after you have activated your account by pressing the url below.
 
------------------------
UserName: '.$member_id.'
Password: '.$password.'
------------------------
 
Please click this link to activate your account:
http://www.InsuredHelp.org/verify.php?email='.$admin_id.'&hash='.$hash.'
 
'; // Our message above including the link
                     
$headers = 'From:noreply@InsuredHelp.org' . "\r\n"; // Set from headers
mail($to, $subject, $message, $headers); // Send our email
			
			
		
  /*                  
                    
 $subject = 'Signup | Verification on InsuredHelp.org'; // Give the email a subject 
$message = '
 
Thanks for signing up on InsuredHelp.org!
Your account has been created, you can login with the following credentials after you have activated your account by pressing the url below.
 
------------------------
UserName: '.$uname.'
Password: '.$password.'
------------------------
 
Please click this link to activate your account:
http://www.InsuredHelp.org/verify.php?email='.$email.'&hash='.$hash.'
 
';
                    
	$mail = new PHPMailer();
        $mail ->isSMTP();
        $mail ->SMTPDebug = 0;
        $mail ->SMTPAuth = true;
        $mail ->SMTPSecure = 'ssl';
        $mail ->Host = "smtp.gmail.com";
        $mail ->Port = 587;
        $mail ->isHTML(true);
        $mail ->Username = "dicksonifediora@gmail.com";
        $mail ->Password = "08064587230";
        $mail ->setFrom("dicksonifediora@gmail.com");
        $mail ->Subject = $subject;
        $mail ->Body = $message;
        $mail ->addAddress("dicksonifediora@yahoo.com");
        
       
        
        if(!$mail ->send()){
            echo "Mail Not Sent";
        }
	else
        {
             echo "Mail Sent";
        }
			
	*/		
	
			
			?>
		
	
	<script type="text/javascript">
alert("Registration Successful. An activation link has been sent to your email address. Please click on the link to activate your account.");
window.location="dashboard.php";
</script>

<?php







   }
//}

?>