<?php ?>
<?php 
session_start();
include ("includes/connect.php");



$ap_id = $_GET['apid'];



        
?>

<?php
$lquery = "UPDATE members SET status = 1 WHERE id = '$ap_id'";
    $lresult = mysqli_query($connection, $lquery);
if($lresult){
        //$_SESSION["message"] = "Transaction Successful!";
        //header ("location: transaction.php");
        ?>
<script type="text/javascript">
    alert("Member Approval Successful!");
    window.location="approve_members.php";
</script>
<?php
    }else{
        //$_SESSION["message"] = "Transaction failed!";
       // header ("location: transaction.php");
        ?>
<script type="text/javascript">
    alert("Member Approval failed!");
    window.location="approve_members.php";
</script>
<?php
       
    }
       


        
?>
