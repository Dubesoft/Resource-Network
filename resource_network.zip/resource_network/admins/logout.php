 <?php 
 session_start();

include ("includes/connect.php");
$admin1_id = $_SESSION['aid'];
 
 $query = "UPDATE admin SET logged = NOW() WHERE id = '$admin1_id'";
 $result = mysqli_query($connection, $query);
 
     if ($result){
	
	 ?>
   <script type="text/javascript">
alert("Goodbye, we will love to see you back soon!");

window.location="../adminsignin.php";
</script>
<?php

die();
   
   }else{

?> 
<script type="text/javascript">
alert("OOps! We were unable to Log you Out");
window.location="dashboard.php";
</script>

<?php
}

     
     
 
    unset($admin1_id);
    $_SESSION = array();
    session_destroy();
    header("Location: adminsignin.php"); 

?>


