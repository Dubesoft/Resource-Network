<?php
//include ("includes/connect.php");
include ("includes/header.php");
include ("includes/navigation.php");
?>


    

<!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <form action="process_deposit.php" method="post">
                                    <h2 style="color: #232347" class="col-sm-offset-5">Deposit</h2>
                                        
                                    <hr>
                                    <br>
                                        
                                            <div class="form-group input-group">                                        
                                                
                                            </div>
                                    <div class="form-group input-group">
                                            <span class="input-group-addon"><span class="input-icon input-icon-user"></span><span class="input-text"></span></span>
                                            <input type="text" class="form-control" placeholder="member_id"  name="member_id" required="required"/>
                                        </div>
                                        <div class="form-group input-group">
                                            <span class="input-group-addon"><span class="input-icon input-icon-user"></span><span class="input-text"></span></span>
                                            <input type="text" class="form-control" placeholder="Amount"  name="amount" required="required"/>
                                        </div>
                                        <div class="form-group input-group">
                                            <span class="input-group-addon"><span class="input-icon input-icon-email"></span><span class="input-text"></span></span>
                                            <input type="text" class="form-control" placeholder="Narration" name="reason" required="required"/>
                                        </div>

                                     
                                        
                                     
                                     
                                    <input type="submit" class="btn btn-success btn-lg btn-md col-sm-offset-5" value="submit">
                                     
                                    <hr />
                                    <?php //echo $_SESSION["message"];
                                    //$amount = $_SESSION["amount"];
                                           // $trans_type = $_SESSION["trans_type"];
                                            //$reason = $_SESSION["reason"];
                                    //echo $amount . "<br>";
                                    //echo $trans_type  . "<br>";
                                    //echo $reason . "<br>";
                                     
                                    ?>
                                    
                                   
                                    </form>
     
      
            </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->

<?php include ("includes/footer.php"); ?>
    