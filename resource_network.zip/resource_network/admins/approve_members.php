<?php include("includes/header.php"); ?>
<?php include("includes/navigation.php"); ?>  
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h2 style="color: #232347" class="col-sm-offset-4">Unapproved Members</h2>   
                        
                       
                    </div>
                </div>
                 <!-- /. ROW  -->
                 <hr />
               
            <div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                             Advanced Tables
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                      <thead>
                            <tr>
                                <th  style="text-align: center;">id</th>
                                <th  style="text-align: center;">First Name</th>
                                <th  style="text-align: center;">Last Name</th>
                                <th  style="text-align: center;">Email</th>
                                <th  style="text-align: center;">Phone Number</th>
                                <!--<th  style="text-align: center;">Picture</th>-->
                                <!--<th>status</th>-->
                                <th  style="text-align: center;">Date</th>
                                <!--<th>Control</th>-->
                                <th></th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>                      
<?php
$query = "SELECT * ";
$query .= "FROM members ";
$query .= "WHERE status = '0' ";          
          $index = 0;
 $result = mysqli_query($connection, $query);
 $counter=1;
       	while ( $row = mysqli_fetch_array($result) ) {
		//$row_count =  mysql_num_rows($result);
                $id = $row['id'];
                ?>
                <tr>
                        <td  style="text-align: center;"><?php echo $counter;?></td>
                        <td  style="text-align: center;"><?php echo $row['firstname'];?></td>
                        <td  style="text-align: center;"><?php echo $row['lastname'];?></td>
                        <td  style="text-align: right;"><?php  echo $row['email']; ?></td>
                        <td  style="text-align: center;"><?php echo $row['phonenumber'];?></td>
                        <!--<td  style="text-align: center;"><img src="<?php echo $imagepath; ?>" alt="user image" height="50" class="img-rounded"></td>-->
                        <!--<td><?php echo $row['status']?></td>-->
                        <td  style="text-align: center;"><?php echo $row['date']?></td>
                        <!--<td><a href="pending_loan.php?lid=<?php echo $id; ?>" class="btn btn-warning  col-lg-offset-2" data-toggle="modal" data-target="#myModal">View Member</a></td>-->
                        <td><a href="process_approve_members.php?apid=<?php echo $id; ?>" class="btn btn-success col-lg-offset-2 glyphicon glyphicon-ok"></a></td>
                        <td><a href="process_loan_decline.php?apid=<?php echo $id; ?>" class="btn btn-danger col-lg-offset-2 glyphicon glyphicon-remove"></a></td>
                      </tr>
                
                
                <?php
                $counter++;
        }
        ?>
          </tbody>
                                </table>
                                
         
                            </div>
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>
            </div>
                <!-- /. ROW  -->
    
                <!-- /. ROW  -->
            
                <!-- /. ROW  -->
 
                <!-- /. ROW  -->
        </div>
               
    </div>
             <!-- /. PAGE INNER  -->
            
         <!-- /. PAGE WRAPPER  -->
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
     <!-- DATA TABLE SCRIPTS -->
    <script src="assets/js/dataTables/jquery.dataTables.js"></script>
    <script src="assets/js/dataTables/dataTables.bootstrap.js"></script>
        <script>
            $(document).ready(function () {
                $('#dataTables-example').dataTable();
            });
    </script>
         <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    
   
</body>
</html>

       