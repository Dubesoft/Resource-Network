<?php 
session_start();
include ("includes/connect.php");

$a_id = $_GET['aid'];
//echo $memberid;


    $wquery = "UPDATE adminmessage SET status = 3 WHERE id = '$a_id'";
    $wresult = mysqli_query($connection, $wquery);
if($wresult){
        //$_SESSION["message"] = "Transaction Successful!";
        //header ("location: transaction.php");
        ?>
<script type="text/javascript">
    alert("Done!");
    window.location="viewmessage.php";
</script>
<?php
    }else{
        //$_SESSION["message"] = "Transaction failed!";
       // header ("location: transaction.php");
        ?>
<script type="text/javascript">
    alert("Failed!");
    window.location="viewmessage.php";
</script>
<?php
       
    }
        
        
?>

