<?php ?>
<?php 
session_start();
include ("includes/connect.php");


$w_id = $_GET['wid'];

$amount = $_GET['amount'];
//echo $w_id. "<br>";
//echo $member_id. "<br>";
//echo $amount;


       
       
        //echo $trans_type;
        
$bquery = "SELECT * ";
$bquery .= "FROM members ";
$bquery .= "WHERE id = '$w_id'";
$bresult = mysqli_query($connection, $bquery);
//confirm_query($result);
       	while ( $row = mysqli_fetch_array($bresult) ) {
		
            $savedbalance = $row['savedbalance'];
        }

    
      
            $savedbalance = $savedbalance - $amount;
            echo $amount . "<br>";
            echo $savedbalance;
        
        //$_SESSION["trans_type"] = $savedbalance;
        
$aquery = "UPDATE members SET savedbalance = $savedbalance WHERE id = '$w_id'";
$result = mysqli_query($connection, $aquery);

    $wquery = "UPDATE withdraw SET status = 1 WHERE id = '$w_id'";
    $wresult = mysqli_query($connection, $wquery);
if($wresult){
        //$_SESSION["message"] = "Transaction Successful!";
        //header ("location: transaction.php");
        ?>
<script type="text/javascript">
    alert("Operation Successful!");
    window.location="pending_withdrawal.php";
</script>
<?php
    }else{
        //$_SESSION["message"] = "Transaction failed!";
       // header ("location: transaction.php");
        ?>
<script type="text/javascript">
    alert("Operation failed!");
    window.location="pending_withdrawal.php";
</script>
<?php
       
    }
        
        
?>

