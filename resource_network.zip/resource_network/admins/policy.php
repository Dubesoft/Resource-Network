<?php include ("includes/header.php"); ?>
<link rel="stylesheet" href="../css/style.css">
<?php include ("includes/Navigation.php"); ?>
  
       <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <form role="form" action="process_policy.php" method="post" enctype="multipart/form-data">
                                    
                     <h2 class="col-sm-offset-5" style="color: #232347">Loan Policy</h2>
                     <hr>
                     <br>
                                       
                                        <div class="form-group input-group">
                                            <span class="input-group-addon"><span class="input-icon input-icon-user"></span><span class="input-text"></span></span>
                                            <input type="text" class="form-control" placeholder="Loan Name"  name="loan_name" required="required"/>
                                        </div>
                                        <div class="form-group input-group">
                                            <span class="input-group-addon"><span class="input-icon input-icon-user"></span><span class="input-text"></span></span>
                                            <input type="text" class="form-control" placeholder="Percentage Saving Rate"  name="psr" required="required"/>
                                        </div>
                                        
                                        <div class="form-group input-group">
                                            <span class="input-group-addon"><span class="input-icon input-icon-user"></span><span class="input-text"></span></span>
                                            <input type="text" class="form-control" placeholder="Months Duration"  name="months_duration" required="required"/>
                                        </div>
                          
                                     <input type="submit" class="btn btn-success btn-lg col-sm-offset-5" value="submit">
                                    <hr />
                                    
                                    </form>
   
     
      
            </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->       
      <?php include ("includes/footer.php"); ?>