<?php
session_start();
include ("includes/connect.php");
//$userid = $_SESSION['id'];
//$puname = $_SESSION['uname'];
$mid = $_GET['mid'];

//if(isset($_POST['submit'])){

    //$fname = $_POST ['fname'];
    //$lname = $_POST ['lname'];
    //$email = $_POST ['email'];
    //$password = $_POST ['password'];
    
    //echo "I am showing";
    
    
 







    $query = "UPDATE members SET status='0' WHERE id = '$mid'";
	$result= mysqli_query($connection, $query) or die(mysqli_error());



if ($result){
	
	 ?>
   <script type="text/javascript">
alert("member de-activation successfully");

window.location="viewmembers.php";
</script>
<?php

die();

   
   }else{
       ?>
 <script type="text/javascript">
alert("member de-activtion failed");

window.location="viewmembers.php";
</script>
<?php
   }
//}
?> 
