<?php include("includes/header.php"); ?>
<?php include("includes/navigation.php"); ?>    
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                    <h2 style="color: #232347" class="col-sm-offset-5">Active Admins</h2>   
                        
                       
                    </div>
                </div>
                 <!-- /. ROW  -->
                 <hr />
               
            <div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                             
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                     <thead>
                            <tr>
                                <th  style="text-align: center;">id</th>
                                <th  style="text-align: center;">Admin id</th>
                                <th  style="text-align: center;">First Name</th>
                                <th  style="text-align: center;">Last Name</th>
                                <th  style="text-align: center;">Email</th>
                               
                                <th  style="text-align: center;">Phone Number</th>
                                
                                <!--<th  style="text-align: center;">Gender</th>-->
                                <!--<th  style="text-align: center;">Picture</th>-->
                                <!--<th>status</th>-->
                                <th  style="text-align: center;">Date</th>
                                <th></th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>                      
<?php
$query = "SELECT * ";
$query .= "FROM admin ";
$query .= "WHERE status = '1' ";         
          $index = 0;
 $result = mysqli_query($connection, $query);
 $counter=1;
       	while ( $row = mysqli_fetch_array($result) ) {
		$id =$row['id'];
                $date = $row['date'];
                $picture = $row['picture'];
                $imagepath = "photo/".$picture;
               
                ?>
                <tr>
                        <td  style="text-align: center;"><?php echo $counter;?></td>
                        <td  style="text-align: center;"><?php echo $row['admin_id'];?></td>
                        <td  style="text-align: center;"><?php echo $row['firstname'];?></td>
                        <td  style="text-align: center;"><?php echo $row['lastname'];?></td>
                        <td  style="text-align: center;"><?php echo $row['email']?></td>
                        
                        <td  style="text-align: center;"><?php echo $row['phonenumber']?></td>
                        
                        <!--<td  style="text-align: center;"><?php echo $row['gender']?></td>-->
                        <!--<td  style="text-align: center;"><img src="<?php echo $imagepath; ?>" alt="user image" height="50" class="img-rounded col-lg-offset-2"></td>-->
                        <!--<td><?php echo $row['status']?></td>-->
                        <td  style="text-align: center;"><?php echo date('d-m-Y', strtotime($date))?></td>
                        <td  style="text-align: center;"><a href="editadmin.php?aid=<?php echo $id; ?>" class="btn btn-warning  col-lg-offset-2 glyphicon glyphicon-edit"></a></td>
                        <td  style="text-align: center;"><a href="process_admin_de-activate.php?aid=<?php echo $id; ?>" class="btn btn-danger col-lg-offset-2 glyphicon glyphicon-remove"></a></td>
                      </tr>
                
                
                <?php
                $counter++;
        }
        ?>
          </tbody>
                                </table>
                            </div>
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>
            </div>
                <!-- /. ROW  -->
    
                <!-- /. ROW  -->
            
                <!-- /. ROW  -->
 
                <!-- /. ROW  -->
        </div>
               
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
     <!-- DATA TABLE SCRIPTS -->
    <script src="assets/js/dataTables/jquery.dataTables.js"></script>
    <script src="assets/js/dataTables/dataTables.bootstrap.js"></script>
        <script>
            $(document).ready(function () {
                $('#dataTables-example').dataTable();
            });
    </script>
         <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    
   
</body>
</html>
