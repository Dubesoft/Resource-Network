<?php ?>
<?php 
session_start();
include ("includes/connect.php");



$l_id = $_GET['lid'];



        
?>

<?php
$lquery = "UPDATE loan SET status = 1 WHERE id = '$l_id'";
    $lresult = mysqli_query($connection, $lquery);
if($lresult){
        //$_SESSION["message"] = "Transaction Successful!";
        //header ("location: transaction.php");
        ?>
<script type="text/javascript">
    alert("Loan Approval Successful!");
    window.location="pending_loan.php";
</script>
<?php
    }else{
        //$_SESSION["message"] = "Transaction failed!";
       // header ("location: transaction.php");
        ?>
<script type="text/javascript">
    alert("Loan Approval failed!");
    window.location="pending_loan.php";
</script>
<?php
       
    }
       


        
?>
