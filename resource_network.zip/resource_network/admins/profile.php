<?php include("includes/header.php"); ?>
<?php include("includes/navigation.php"); ?>  
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <form role="form" action="process_editadminprofile.php" method="post" enctype="multipart/form-data" onsubmit="if(!confirm('Are you sure you want to make changes to this record?')){return false;}">
                   
                      <h2 class="col-sm-offset-5" style="color: #232347">Profile</h2>
                     <hr>
                     <br>
        
                                    <div class="container-fluid"><img src="<?php echo $imagepath; ?>" alt="user image" height="150" class="col-lg-offset-5 img-rounded"></div>
                                    <h4>Photo Upload</h4>
                                    <input type="hidden" name="MAX_FILE_SIZE" value="1000000">
                                        <p><input type="file" name="file" class="btn btn-default"></p>
                                        <input type="submit" class="btn btn-default" value="Upload Picture" name="upload">
                             
<br>
<br>
                                        <div class="form-group input-group">
                                            <span class="input-group-addon"><span class="input-icon input-icon-user"></span><span class="input-text">Admin id</span></span>
                                            <input type="text" class="form-control transparent" placeholder="Admin id"  name="admin_id" value="<?php echo $admin_id;?>"/>
                                                
                                        </div>
                                        <div class="form-group input-group">
                                            <span class="input-group-addon"><span class="input-icon input-icon-user"></span><span class="input-text">First Name</span></span>
                                            <input type="text" class="form-control transparent" placeholder="First Name"  name="fname" value="<?php echo $fname ;?>"/>
                                                
                                        </div>
                                        <div class="form-group input-group">
                                            <span class="input-group-addon"><span class="input-icon input-icon-user"></span><span class="input-text">Last Name</span></span>
                                            <input type="text" class="form-control" placeholder="Last Name"  name="lname" value="<?php echo $lname;?>"/>
                                                
                                        </div>
                                        <div class="form-group input-group">
                                            <span class="input-group-addon"><span class="input-icon input-icon-email"></span><span class="input-text">Email</span></span>
                                            <input type="text" class="form-control" placeholder="Email" name="email"  value="<?php echo $email;?>"/>
                                                
                                        </div>

                                     <div class="form-group input-group">
                                            <span class="input-group-addon"><span class="input-icon input-icon-user"></span><span class="input-text">Password</span></span>
                                            <input type="password" class="form-control" placeholder="Password" name="password"/>  
                                        </div>
                                        
                                        <div class="form-group input-group">
                                            <span class="input-group-addon"><span class="input-icon input-icon-email"></span><span class="input-text">Phone Number</span></span>
                                            <input type="text" class="form-control" placeholder="Phone Number" name="phone"  value="<?php echo $phone;?>"/>
                                        </div>
                                        <div class="form-group input-group">                                        
                                                <select name="gender" class="chosen-select form-control">
                                                    <option value="<?php echo $gender; ?>"></option>
                                                    <option value="male">Male</option>
                                                    <option value="female">Female</option>
                                                </select>
                                            </div>
                                        
                                        <div class="form-group input-group">
                                            <span class="input-group-addon"><span class="input-icon input-icon-email"></span><span class="input-text">Date</span></span>
                                            <input type="text" class="form-control" placeholder="Date" name="date"  value="<?php echo date('d-m-Y', strtotime($date));?>"/>
                                        </div>
                                         <input type="submit" class="btn btn-success btn-lg btn-md col-sm-offset-5" value="Update">
                                        
          </form>
   
     
      
            </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        <?php include("includes/footer.php"); ?>