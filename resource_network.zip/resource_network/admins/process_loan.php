<?php 
session_start();
include ("connect.php");


    $amount = $_POST ['amount'];
    $trans_type = $_POST ['trans_type'];
    $reason = $_POST ['reason'];
    
    
    //$_SESSION["amount"] = $amount;
    //$_SESSION["trans_type"] = $trans_type;
    //$_SESSION["reason"] = $reason;
    //header ("location: transaction.php");

    
    $query = "SELECT * ";
$query .= "FROM loantype ";
$query .= "WHERE loantype = '$trans_type' ";         
          //$index = 0;
 $result = mysqli_query($connection, $query);
       	while ( $row = mysqli_fetch_array($result) ) {
		//$row_count =  mysql_num_rows($result);
                $trans_type_id =$row['id'];
		$interest_rate =$row['interest_rate'];
                //$first = $_SESSION['fname'];
                $max_duration =$row['max_duration'];
		//$_SESSION['amount']= $row['amount'];
                //$_SESSION['date_applied']= $row['date_applied'];
                //$_SESSION['reason']= $row['reason'];
        }
        
        $_SESSION["trans_type_id"] = $trans_type_id;
        $_SESSION["interest_rate"] = $interest_rate;
        $_SESSION["max_duration"] = $max_duration;
    
    
  
    $query = "INSERT INTO loan (";
    $query .= " applied_date, status, amount, reason, loantype_id, interest,duration";
    $query .= ") VALUES (";
    $query .=" NOW(), 0, {$amount}, '{$reason}', {$trans_type_id}, {$interest_rate}, {$max_duration}";
    $query .= ")";
    
    
    $tresult = mysqli_query($connection, $query);
    if($tresult){
        //$_SESSION["message"] = "Transaction Successful!";
        //header ("location: transaction.php");
        ?>
<script type="text/javascript">
    alert("Transaction Successful!");
    window.location="loan.php";
</script>
<?php
    }else{
        //$_SESSION["message"] = "Transaction failed!";
       // header ("location: transaction.php");
        ?>
<script type="text/javascript">
    alert("Transaction failed!");
    window.location="loan.php";
</script>
<?php
       
    }
     
    //}
     //header ("location: transaction.php");
?>