<?php 
session_start();
include ("includes/connect.php");

$l_id = $_GET['lid'];
//echo $memberid;


    $wquery = "UPDATE loan SET status = 3 WHERE id = '$l_id'";
    $wresult = mysqli_query($connection, $wquery);
if($wresult){
        //$_SESSION["message"] = "Transaction Successful!";
        //header ("location: transaction.php");
        ?>
<script type="text/javascript">
    alert("Loan Decline Successful!");
    window.location="pending_loan.php";
</script>
<?php
    }else{
        //$_SESSION["message"] = "Transaction failed!";
       // header ("location: transaction.php");
        ?>
<script type="text/javascript">
    alert("Loan Decline failed!");
    window.location="pending_loan.php";
</script>
<?php
       
    }
        
        
?>

