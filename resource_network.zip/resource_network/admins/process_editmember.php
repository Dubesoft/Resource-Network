<?php
session_start();
include ("includes/connect.php");
$member_id = $_SESSION['mid'];
echo $member_id;
//$puname = $_SESSION['uname'];

//if(isset($_POST['submit'])){
    $staff_id = $_POST ['staff_id'];
    $fname = $_POST ['fname'];
    $lname = $_POST ['lname'];
    $email = $_POST ['email'];
    $password = $_POST ['password'];
    $address = $_POST ['address'];
    $phone = $_POST ['phone'];
    $gender = $_POST ['gender'];
    $balance = $_POST ['balance'];
    $date = $_POST ['date'];
    
    
    //echo "I am showing";

    
    
   // $caption = $_POST ['caption'];
/*
$file = $_FILES['file']['name'];
$file_loc = $_FILES['file']['tmp_name'];
$file_size = $_FILES['file']['size'];
$file_type = $_FILES['file']['type'];

$folder ="photo/";
$new_size =  $file_size/1024;
$new_file_name = strtolower($file);
$final_file = str_replace(' ', '-', $new_file_name);

move_uploaded_file($file_loc, $folder.$final_file);
 //$psql="UPDATE photos set filename= '$final_file', type='$file_type',  size= '$new_size', caption= '$caption' WHERE uname ='$puname'"; 

       
//$presult=mysql_query($psql) or die(mysql_error());
*/


if (empty($password)){
    $epassword = md5($password);
    $query = "UPDATE members SET staff_id = '$staff_id', firstname = '$fname', lastname = '$lname', email = '$email', ";
     $query .="address = '$address', phonenumber = '$phone', gender = '$gender',  savedbalance = {$balance}, date = '$date' WHERE id = '$member_id'";
     $result = mysqli_query($connection, $query);
     
    
}else{
    $epassword = md5($password);
	$query = "UPDATE members SET staff_id = '$staff_id', firstname = '$fname', lastname = '$lname', email = '$email', password = '$epassword', ";
     $query .="address = '$address', phonenumber = '$phone', gender = '$gender',  savedbalance = '{$balance}', date = '$date' WHERE id = '$member_id'";
     $result = mysqli_query($connection, $query);
}


//if(isset($_POST['upload'])){
    //$query = "UPDATE members SET picture='$final_file' WHERE id = '$member_id'";
	//$result= mysqli_query($connection, $query);
//}

if(isset($_POST['upload'])){
    
    $file = $_FILES['file']['name'];
$file_loc = $_FILES['file']['tmp_name'];
$file_size = $_FILES['file']['size'];
$file_type = $_FILES['file']['type'];

$folder ="photo/";
$new_size =  $file_size/1024;
$new_file_name = strtolower($file);
$final_file = str_replace(' ', '-', $new_file_name);

move_uploaded_file($file_loc, $folder.$final_file);
    
    $query = "UPDATE members SET picture='$final_file' WHERE id = '$member_id'";
	$result= mysqli_query($connection, $query);
}


if ($result){
	
	 ?>
   <script type="text/javascript">
alert("Changes saved successfully");

window.location="viewmembers.php";
</script>
<?php

die();
   
   }else{

?> 
<script type="text/javascript">
alert("Unable to save Changes");
window.location="viewmembers.php";
</script>

<?php
}
?>