<?php include("includes/header.php"); ?>
<?php include("includes/navigation.php"); ?>  
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <form role="form" action="process_adminsignup.php" method="post" enctype="multipart/form-data">
        <h2 style="color: #232347" class="col-sm-offset-5">CREATE ADMIN</h2>
        <hr>
        <br>
        <h4>Photo Upload</h4>
                                    
                                    <input type="hidden" name="MAX_FILE_SIZE" value="1000000">
                                        <p><input type="file" name="file" class="btn btn-default"></p>
                                        <input type="submit" class="btn btn-default" value="Upload Picture" name="upload">
                             
<br>
<br>
                                         <div class="form-group input-group">
                                            <span class="input-group-addon"><span class="input-icon input-icon-user"></span><span class="input-text"></span></span>
                                            <input type="text" class="form-control transparent" placeholder="Admin id"  name="admin_id" value=""/>
                                                
                                        </div>
                                        <div class="form-group input-group">
                                            <span class="input-group-addon"><span class="input-icon input-icon-user"></span><span class="input-text"></span></span>
                                            <input type="text" class="form-control transparent" placeholder="First Name"  name="fname" value=""/>
                                                
                                        </div>
                                        <div class="form-group input-group">
                                            <span class="input-group-addon"><span class="input-icon input-icon-user"></span><span class="input-text"></span></span>
                                            <input type="text" class="form-control" placeholder="Last Name"  name="lname" value=""/>
                                                
                                        </div>
                                        <div class="form-group input-group">
                                            <span class="input-group-addon"><span class="input-icon input-icon-email"></span><span class="input-text"></span></span>
                                            <input type="text" class="form-control" placeholder="Email" name="email"  value=""/>
                                                
                                        </div>

                                     <div class="form-group input-group">
                                            <span class="input-group-addon"><span class="input-icon input-icon-user"></span><span class="input-text"></span></span>
                                            <input type="password" class="form-control" placeholder="Password" name="password"/>
                                                
                                        </div>
                                        <div class="form-group input-group">
                                            <span class="input-group-addon"><span class="input-icon input-icon-user"></span><span class="input-text"></span></span>
                                            <input type="password" class="form-control" placeholder="Retype Password" name="repass"/>
                                                
                                        </div>
                                        
                                    <input type="submit" class="btn btn-success btn-lg col-sm-offset-5" value="Submit" >
                                        
          </form>
   
     
      
            </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        <?php include("includes/footer.php"); ?>