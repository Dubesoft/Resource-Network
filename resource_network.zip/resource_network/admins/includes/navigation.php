<?php
//include ("connect.php");
//session_start();
$admin1_id = $_SESSION['aid'];
//echo $memberid;
//cho $puname;
/*
$psql="SELECT * FROM photos  WHERE uname = '$puname'" ;
 $presult=mysql_query($psql) or die(mysql_error());
       	while ( $row = mysql_fetch_array($presult) ) {
		
                //$_SESSION['filename'] = null;
		$_SESSION['filename'] =$row['filename'];
                //echo $_SESSION['filename'];
                $imagepath = "photo/".$_SESSION['filename'];
                echo $imagepath;
                
                //echo $_SESSION['fname'];
        }
 * 
 */
$query = "SELECT * ";
$query .= "FROM adminmessage ";
$query .= "WHERE status = '0' ";
$result = mysqli_query($connection, $query);
       	while ($row = mysqli_fetch_array($result) ) {	
                $message_count =  mysqli_num_rows($result);
  
        }
        
$query = "SELECT * ";
$query .= "FROM withdraw ";
$query .= "WHERE status = '0' ";
$result = mysqli_query($connection, $query);
       	while ($row = mysqli_fetch_array($result) ) {	
                $withdrawal_count =  mysqli_num_rows($result);
  
        }
        
$query = "SELECT * ";
$query .= "FROM withdraw ";
$result = mysqli_query($connection, $query);
       	while ($row = mysqli_fetch_array($result) ) {	
                $total_withdrawal_count =  mysqli_num_rows($result);
  
        }
        
/*       
$query = "SELECT * ";
$query .= "FROM members ";
$query .= "WHERE id = '$m_id' ";
$result = mysqli_query($connection, $query);
       	while ($row = mysqli_fetch_array($result) ) {	
                $balance = $row['savedbalance'];
                $total_balance = $total_balance + $balance;
        }
        
 * 
 */
$query = "SELECT * ";
$query .= "FROM loan ";
$query .= "WHERE status = '0' ";
$result = mysqli_query($connection, $query);
       	while ($row = mysqli_fetch_array($result) ) {	
                $loan_count =  mysqli_num_rows($result);
  
        }



$query = "SELECT * ";
$query .= "FROM members ";
$query .= "WHERE status = '1' ";
$result = mysqli_query($connection, $query);
       	while ($row = mysqli_fetch_array($result) ) {	
                $members_count =  mysqli_num_rows($result);
                $picture = $row['picture'];
                $imagepath = "photo/".$picture;
                
                //echo $_SESSION['fname'];
        }

$query = "SELECT * ";
$query .= "FROM admin ";
$query .= "WHERE status = '1' ";
$result = mysqli_query($connection, $query);
       	while ($row = mysqli_fetch_array($result) ) {	
                $admin_count =  mysqli_num_rows($result);
                
               
                
                //echo $_SESSION['fname'];
        }
        
$query = "SELECT * ";
$query .= "FROM admin ";
$query .= "WHERE id = '$admin1_id' ";
$result = mysqli_query($connection, $query);
       	while ($row = mysqli_fetch_array($result) ) {	
                $picture = $row['picture'];
                $imagepath = "photo/".$picture;
                $position = $row['position'];
                //echo $_SESSION['fname'];
                $fname = $row['firstname'];
                $lname = $row['lastname'];
                $email = $row['email'];
                $admin_id = $row['admin_id'];
                $gender = $row['gender'];
               
                $phone = $row['phonenumber'];
                
                //$savedbalance = $row['savedbalance'];
                $date = $row['date'];
        }
     
        ?>


                <nav class="navbar-default navbar-side" role="navigation" >
            <div class="sidebar-collapse">
                <?php if($position == "5"){?>
                <ul class="nav" id="main-menu">
				<li class="text-center">
                                    <img src="<?php echo $imagepath; ?>" class="user-image img-responsive" alt="user-image"/>
                                </li>
                    <?php $link = basename($_SERVER ['PHP_SELF'], ".php"); //$test = "working";
                    
                    ?>
					
                    <li>
                        <a class="<?php if ($link == "dashboard") {echo "active-menu"; } ?>"  href="dashboard.php" ><i class="fa fa-dashboard fa-3x"></i> Dashboard</a>
                    </li>
                    <li>
                        <a class="<?php if ($link == "profile") {echo "active-menu"; }?>" href="profile.php"><i class="fa fa-desktop fa-3x"></i>Profile</a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-wrench fa-3x"></i>policy Setup</a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a class="<?php if ($link == "loan_setup"){echo "active-menu"; } ?>" href="loan_setup.php">Loan Policy</a>
                            </li>
                            <li>
                                <a class="<?php if ($link == "withdrawal_policy"){echo "active-menu"; } ?>" href="withdrawal_policy.php">Withdrawal Policy</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a class="<?php if ($link == "pending_loan"){echo "active-menu"; } ?>" href="pending_loan.php"><i class="fa fa-cog fa-3x"></i>Pending Loan</a>
                    </li>
                    <li>
                        <a class="<?php if ($link == "pending_withdrawal"){echo "active-menu"; } ?>" href="pending_withdrawal.php"><i class="fa fa-cog fa-3x"></i>Pending Withdrawal</a>
                    </li>
                    <li>
                        <a class="<?php if ($link == "deposit"){echo "active-menu"; } ?>" href="deposit.php"><i class="glyphicon glyphicon-log-in fa-3x"></i>Deposit</a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-sitemap fa-3x"></i>Members<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a class="<?php if ($link == "viewmembers"){echo "active-menu"; } ?>" href="viewmembers.php">View Members</a>
                            </li>
                            <li>
                                <a class="<?php if ($link == "createmembers"){echo "active-menu"; } ?>" href="createmembers.php">Create Members</a>
                            </li>
                            <li>
                                <a class="<?php if ($link == "approve_members"){echo "active-menu"; } ?>" href="approve_members.php">Approve Members</a>
                            </li>
                        </ul>
                      </li>
                      <li>
                        <a href="#"><i class="fa fa-sitemap fa-3x"></i>Admins<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a class="<?php if ($link == "viewadmins"){echo "active-menu"; } ?>" href="viewadmins.php">View Admins</a>
                            </li>
                            <li>
                                <a class="<?php if ($link == "createadmins"){echo "active-menu"; } ?>" href="createadmins.php">Create Admins</a>
                            </li>
                           
                 
                        </ul>
                      </li>  
                      <li>
                        <a class="<?php if ($link == "viewmessage") {echo "active-menu"; } ?>"  href="viewmessage.php" ><i class="fa fa-envelope fa-3x"></i>Support Ticket</a>
                    </li>
                </ul>
                <?php }else if($position == "4"){ ?>
               
                <ul class="nav" id="main-menu">
				<li class="text-center">
                                    <img src="<?php echo $imagepath; ?>" class="user-image img-responsive" alt="user-image"/>
                                </li>
                    <?php $link = basename($_SERVER ['PHP_SELF'], ".php"); //$test = "working";
                    
                    ?>
					
                     <li>
                        <a class="<?php if ($link == "dashboard") {echo "active-menu"; } ?>"  href="dashboard.php" ><i class="fa fa-dashboard fa-3x"></i> Dashboard</a>
                    </li>
                    <li>
                        <a class="<?php if ($link == "profile") {echo "active-menu"; }?>" href="profile.php"><i class="fa fa-desktop fa-3x"></i>Profile</a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-wrench fa-3x"></i>policy Setup</a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a class="<?php if ($link == "loan_setup"){echo "active-menu"; } ?>" href="loan_setup.php">Loan Policy</a>
                            </li>
                            <li>
                                <a class="<?php if ($link == "withdrawal_policy"){echo "active-menu"; } ?>" href="withdrawal_policy.php">Withdrawal Policy</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a class="<?php if ($link == "pending_loan"){echo "active-menu"; } ?>" href="pending_loan.php"><i class="fa fa-cog fa-3x"></i>Pending Loan</a>
                    </li>
                    <li>
                        <a class="<?php if ($link == "pending_withdrawal"){echo "active-menu"; } ?>" href="pending_withdrawal.php"><i class="fa fa-cog fa-3x"></i>Pending Withdrawal</a>
                    </li>
                    <li>
                        <a class="<?php if ($link == "deposit"){echo "active-menu"; } ?>" href="deposit.php"><i class="glyphicon glyphicon-log-in fa-3x"></i>Deposit</a>
                    </li>
                </ul>
                <?php }else if($position == "3"){ ?>
               
                <ul class="nav" id="main-menu">
				<li class="text-center">
                                    <img src="<?php echo $imagepath; ?>" class="user-image img-responsive" alt="user-image"/>
                                </li>
                    <?php $link = basename($_SERVER ['PHP_SELF'], ".php"); //$test = "working";
                    
                    ?>
					
                     <li>
                        <a class="<?php if ($link == "dashboard") {echo "active-menu"; } ?>"  href="dashboard.php" ><i class="fa fa-dashboard fa-3x"></i> Dashboard</a>
                    </li>
                    <li>
                        <a class="<?php if ($link == "profile") {echo "active-menu"; }?>" href="profile.php"><i class="fa fa-desktop fa-3x"></i>Profile</a>
                    </li>
                    
                    <li>
                        <a class="<?php if ($link == "pending_loan"){echo "active-menu"; } ?>" href="pending_loan.php"><i class="fa fa-cog fa-3x"></i>Pending Loan</a>
                    </li>
                    <li>
                        <a class="<?php if ($link == "pending_withdrawal"){echo "active-menu"; } ?>" href="pending_withdrawal.php"><i class="fa fa-cog fa-3x"></i>Pending Withdrawal</a>
                    </li>
                    <li>
                        <a class="<?php if ($link == "deposit"){echo "active-menu"; } ?>" href="deposit.php"><i class="glyphicon glyphicon-log-in fa-3x"></i>Deposit</a>
                    </li>
                </ul>
                <?php }else if($position == "2"){ ?>
               
                <ul class="nav" id="main-menu">
				<li class="text-center">
                                    <img src="<?php echo $imagepath; ?>" class="user-image img-responsive" alt="user-image"/>
                                </li>
                    <?php $link = basename($_SERVER ['PHP_SELF'], ".php"); //$test = "working";
                    
                    ?>
					
                    <li>
                        <a class="<?php if ($link == "dashboard") {echo "active-menu"; } ?>"  href="dashboard.php" ><i class="fa fa-dashboard fa-3x"></i> Dashboard</a>
                    </li>
                    <li>
                        <a class="<?php if ($link == "profile") {echo "active-menu"; }?>" href="profile.php"><i class="fa fa-desktop fa-3x"></i>Profile</a>
                    </li>
                    
                    <li>
                        <a class="<?php if ($link == "deposit"){echo "active-menu"; } ?>" href="deposit.php"><i class="glyphicon glyphicon-log-in fa-3x"></i>Deposit</a>
                    </li>
                </ul>
                
                <?php }?>
                
            </div>
            
        </nav> 