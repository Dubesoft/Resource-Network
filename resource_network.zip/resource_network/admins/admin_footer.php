<!--Footer Section Start Here -->
    <footer id="footer">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-4">
                    <div class="footer-logo">
                        <a href="index.php" title="Welcome to Resource Network"><h6 style="color: white">Resource Network</h6></a>
                    </div>
                    <p>
                        It is a fundraising association that works globally to provide support in education via resource network. Their members have spread worldwide to ensure that fundraising amount to delivering at the right place and for the right purposes
                    </p>
                    <address>
                        <span> <i class="fa fa-home"></i> <span>A-105, Sector-82, Agra, 282001, Nigeria</span> </span>
                        <span> <i class="fa fa-phone-square"></i> <span>+234 7068917145</span> </span>
                        <span> <i class="fa fa-envelope"></i> <span><a href="mailto:contact@charity.com">contact@resourcenetwork.com</a></span> </span>
                    </address>

                </div>
                <div class="col-xs-12 col-sm-4 twitter-update">
                    <h6>Twitter Feed</h6>
                    <p>
                        <a href="#"> <span class="Resource Network">@Resource Network</span> We are a charity trust that dedicatedly work for several countries around the globe.  Twitter Alerts will provide your some critical information about those people that need help of yours. <span class="comment-time">2 hours ago</span> </a>
                    </p>
                    <p>
                        <a href="#"> <span class="Resource Network">@c</span> Use Twitter as the best conversation platform to make the people aware of the worst situation that many of Africans are facing. Tweet for them and raise fund in the best possible way. <span class="comment-time">2 hours ago</span> </a>
                    </p>
                </div>
                <div class="col-xs-12 col-sm-4">
                    <h6>Newsletter Signup</h6>
                    <p>

                        Sign up your account to check our newsletter that will undoubtedly help you acquainted with current scenario.
                    </p>
                    <form role="form" class="sign-up">

                        <div class="input-group">
                            <input class="form-control" type="email" placeholder="Email">
                            <div class="input-group-addon">
                                <input type="submit" class="btn btn-theme" value="Submit">
                            </div>
                        </div>

                    </form>

                    <h6>Follow us</h6>
                    <ul class="social-icons">
                        <li>
                            <a href="http://facebook.com" target="_blank"><i class="fa fa-facebook"></i></a>
                        </li>
                        <li>
                            <a href="http://twitter.com" target="_blank"><i class="fa fa-twitter"></i></a>
                        </li>
                        <li>
                            <a href="http://dribble.com/" target="_blank"><i class="fa fa-dribbble"></i></a>
                        </li>
                        <li>
                            <a href="http://pinterest.com" target="_blank"><i class="fa fa-pinterest"></i></a>
                        </li>
                        <li>
                            <a href="http://plus.google.com" target="_blank"><i class="fa fa-google-plus"></i></a>
                        </li>
                        <li>
                            <a href="http://instagram.com" target="_blank"><i class="fa fa-instagram"></i></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="copyright">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
								<span> &copy; Copyright 2017, All Rights Reserved by Samuel Serena.
									</span>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!--Footer Section End Here -->

</div>



                </form>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div>
<!-- donation form popup -->

<script src="assets/js/jquery.min.js"></script>
<!-- Switcher Style Js -->
<script src="assets/js/style-switcher/assets/js/style.switcher.js"></script>
<script src="assets/js/jquery.cookie.js"></script>
<!-- Switcher Style End Js -->
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/jquery.easing.min.js"></script>
<!--Main Slider Js-->
<script src="assets/revolution-slider/js/jquery.themepunch.plugins.min.js"></script>
<script src="assets/revolution-slider/js/jquery.themepunch.revolution.js"></script>
<!--Main Slider End Js-->
<script src="assets/js/jquery.flexslider.js"></script>
<script src="assets/js/site.js"></script>
</body>
</html>