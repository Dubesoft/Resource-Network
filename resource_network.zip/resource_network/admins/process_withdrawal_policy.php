<?php 
session_start();
include ("includes/connect.php");


    $duration = $_POST ['duration'];
    $percentage = $_POST ['percentage'];
    $no_deposit = $_POST ['deposit'];
   
    
    
    //$duration = $months_duration * $years_duration;
    //$_SESSION["amount"] = $amount;
    //$_SESSION["trans_type"] = $trans_type;
    //$_SESSION["reason"] = $reason;
    //header ("location: transaction.php");
$query = "UPDATE withdrawal_policy SET no_deposit = '{$no_deposit}', percentage = {$percentage},"; 
$query .= " duration = {$duration}, date = NOW()";
$result = mysqli_query($connection, $query); 
  /*
    $query = "INSERT INTO withdrawal_policy (";
    $query .= " no_deposit, percentage, duration, date";
    $query .= ") VALUES (";
    $query .=" '{$no_deposit}', {$percentage}, {$duration}, NOW()";
    $query .= ")";
    $result = mysqli_query($connection, $query); 
   * 
   */
    if($result){
          //$_SESSION["message"] = "Transaction Successful!";
        //header ("location: transaction.php");
        ?>
<script type="text/javascript">
    alert("Withdrawal Policy Setup Successful!");
    window.location="withdrawal_policy.php";
</script>
<?php
    }else{
        //$_SESSION["message"] = "Transaction failed!";
       // header ("location: transaction.php");
        ?>
<script type="text/javascript">
    alert("Withdrawal Policy Setup failed!");
    window.location="withdrawal_policy.php";
</script>
<?php
    }
    
    
?>