<?php 
session_start();
include ("includes/connect.php");

    $name = $_POST ['name'];
    $subject = $_POST ['subject'];
    $msg = $_POST ['msg'];
    

    $query = "INSERT INTO  staffmessage(";
    $query .= " date, name, subject, message, status";
    $query .= ") VALUES (";
    $query .=" NOW(), '{$name}', '{$subject}', '{$msg}', 0";
    $query .= ")";
    $result = mysqli_query($connection, $query);

    
if($result){
        //$_SESSION["message"] = "Transaction Successful!";
        //header ("location: transaction.php");
        ?>
<script type="text/javascript">
    alert("Message Sent Successful!");
    window.location="composemessage.php";
</script>
<?php
    }else{
        //$_SESSION["message"] = "Transaction failed!";
       // header ("location: transaction.php");
        ?>
<script type="text/javascript">
    alert("Meessage Sending Failed!");
    window.location="composemessage.php";
</script>
<?php
    }
     
    //}
     //header ("location: transaction.php");
?>