<?php 
session_start();
include ("includes/connect.php");


    $amount = $_POST ['amount'];
    $member_id = $_POST ['member_id'];
    //$trans_type = $_POST ['trans_type'];
    $reason = $_POST ['reason'];
    
    
    //$_SESSION["amount"] = $amount;
    //$_SESSION["trans_type"] = $trans_type;
    //$_SESSION["reason"] = $reason;
    //header ("location: transaction.php");

    
    $query = "INSERT INTO transaction(";
    $query .= " trans_date, amount, narration, trans_type, staff_id";
    $query .= ") VALUES (";
    $query .=" NOW(), {$amount}, '{$reason}', '3', '{$member_id}'";
    $query .= ")";
    $tresult = mysqli_query($connection, $query);
    
    
    
    
    $dquery = "INSERT INTO  deposit(";
    $dquery .= " date, amount, narration, member_id";
    $dquery .= ") VALUES (";
    $dquery .=" NOW(), {$amount}, '{$reason}', '{$member_id}'";
    $dquery .= ")";
    $dresult = mysqli_query($connection, $dquery);
    /*
    if($result){
        $_SESSION["message"] = "Transaction Successful!";
        header ("location: transaction.php");
    }else{
        $_SESSION["message"] = "Transaction failed!";
        header ("location: transaction.php");
        echo "The content is: " . $query;
    }
    
     * 
     */
$bquery = "SELECT * ";
$bquery .= "FROM members ";
$bquery .= "WHERE staff_id = '$member_id'";
$bresult = mysqli_query($connection, $bquery);
//confirm_query($result);
while ( $row = mysqli_fetch_array($bresult) ) {
		
            $savedbalance =$row['savedbalance'];
		

}
        
$savedbalance = $savedbalance + $amount;
     
$aquery = "UPDATE members SET savedbalance = $savedbalance WHERE staff_id = '$member_id'";
$aresult = mysqli_query($connection, $aquery);
    
   
echo $savedbalance;
     //header ("location: transaction.php");
if($aresult){
        //$_SESSION["message"] = "Transaction Successful!";
        //header ("location: transaction.php");
        ?>
<script type="text/javascript">
    alert("Deposit Successful!");
    window.location="deposit.php";
</script>
<?php
    }else{
        //$_SESSION["message"] = "Transaction failed!";
       // header ("location: transaction.php");
        ?>
<script type="text/javascript">
    alert("Deposit failed!");
    window.location="deposit.php";
</script>
<?php
    }
     
    //}
     //header ("location: transaction.php");
?>