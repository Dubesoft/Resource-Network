<?php
if(isset($_POST['login'])){
    include ("Connect.php");
    $staff_id = $_POST['staff_id'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM members WHERE staff_id = '$staff_id' AND password = '$password'";
    $result = mysqli_query($link, $sql);
    while($row = mysqli_fetch_array($result)){
        $rows = mysqli_num_rows($result);
        //for global variable
            $_SESSION['id'] = $row['id'];
    }




    if ($result){


        header("location: member/dashboard.php");

    }
    else{ echo "staff_id or Password Invalid";

    }
    mysqli_close($link);
}


?>