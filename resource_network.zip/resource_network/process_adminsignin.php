<?php
session_start();
	include ("admins/includes/connect.php");
	
        if(isset($_POST['submit'])){
	 	$admin_id = $_POST ['admin_id'];
		$password = $_POST ['password'];
                
               
                
		
		
		//$uname = trim($uname);
                //$password = trim($password);
		
                //$uname= htmlspecialchars($uname);
		//$password = htmlspecialchars($password);
		
                
                //$uname = stripslashes($unmae);
                //$password = stripslashes($password);
                
		
	$epassword = md5($password);
        /*
        $_SESSION['uname'] = null;
        $psql="SELECT * FROM photos  WHERE uname = '$uname'" ;
 $presult=mysql_query($psql) or die(mysql_error());
       	while ( $row = mysql_fetch_array($presult) ) {
		
            
            $_SESSION['uname']= $row['uname'];
        }
        
         * 
         */
        
function mysql_prep($string){
     global $connection;
     
     $escaped_string = mysqli_real_escape_string($connection, $string);
     return $escaped_string;
 }
        
        
       // function confirm_query($result_set){
     //if (!$result_set){
       //  die("Database query failed.");
     //}
 //}        
        
        
$query = "SELECT * ";
$query .= "FROM admin ";
$query .= "WHERE admin_id = '$admin_id' ";
$query .= "AND password = '$epassword' ";
$query .= "AND status = '1' ";
$result = mysqli_query($connection, $query);
//confirm_query($result);


//confirm_query($result);
 
       	while ( $row = mysqli_fetch_array($result) ) {
		
            
            $_SESSION['aid']= $row['id'];
            //$_SESSION['admin_id']= $row['admin_id'];
            //$_SESSION['password']= $row['password'];
            
	/*
			//echo $username;
			//echo $password;
		//$_SESSION['id']= $row['reg'];
		$_SESSION['status'] =$row['status'];
		$_SESSION['email']= $row['email'];
			$_SESSION['id']= $row['id'];
			$_SESSION['name']= $row['name'];
			$allow= $row['allow'];
		//$date = date('Y-m-d H:i:s');
		//$time = date("h:i:sa");
		
		
		/*while ($allow == 0){
			header ("location: dashboard3.php");
              quit();

		}
		*/
			
header ("location: admins/dashboard.php");
die();
        }
		}else{
                  //header ("location: adminsignin.php");  
                

		?>	

   <script type="text/javascript">
alert("Username or password is incorrect. Ensure you have clicked the activation link sent to your email");
window.location="adminsignin.php";
</script>
<?php
                }
die();

   
			

?>