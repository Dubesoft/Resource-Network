<?php include("includes/header.php");?>
    <!-- site content -->
    <div id="main">
        <!-- Breadcrumb Section Start Here -->

        <!-- Breadcrumb Section End Here -->


                        <div class="row">


                                <div class="col-md-4   col-sm-offset-1">

                                    <div class="panel panel-default">
                                        <div class="panel-heading">

                                        </div>
                                        <div class="panel-body">
                                            <form role="form" action="aloginaction.php" method="post" >
                                                <br />
                                                <div class="form-group input-group">
                                                    <span class="input-group-addon"><i class="fa fa-tag"  ></i></span>
                                                    <input type="text" class="form-control" name="name" placeholder="Name " />
                                                </div>
                                                <div class="form-group input-group">
                                                    <span class="input-group-addon"><i class="fa fa-lock"  ></i></span>
                                                    <input type="password" class="form-control"  name="email" placeholder="Email" />
                                                </div>


                                                <div class="form-group input-group">
                                                    <span class="input-group-addon"><i class="fa fa-tag"  ></i></span>
                                                    <textarea placeholder="Message" class="form-control" cols="60" rows="5"></textarea>
                                                </div>

                                                <input type="submit" NAME="Send" value="Send" class="btn-success">

                                            </form>
                            </div>

                        </div>
                    </div>
                    <br>
                            <br>
                            <br>

                            <div class="col-md-2  col-sm-offset-2">
                                <strong class="article-sammury">

                                    RESOURCE NETWORK THRIFT COOPERATIVE SOCIETY

                                </strong>
                                <strong class="contact-address">
                                    <p>
                                        Delta State Innovation Hub<br>
                                        DBS junction off Okpanam Road<br>
                                        Email:resourcenetwork@gmail.com<br>
                                        Telephone:+234 7068917145
                                    </p>


                                </strong>

                            </div>

                        </div>
    </div>

                </section>
                <!-- Our Story Section Start Here -->
                <!-- What We Do Section Start Here-->
            </div>
        </div>
    </div>

               <?php include ("includes/footer.php");?>