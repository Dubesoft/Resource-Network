<?php include ("includes/header.php");?>
<html>
    <head>
        <body>
    <script language="JavaScript">
        <!--
        function showpay() {
            if ((document.calc.loan.value == null || document.calc.loan.value.length == 0) ||
                (document.calc.months.value == null || document.calc.months.value.length == 0)
                ||
                (document.calc.rate.value == null || document.calc.rate.value.length == 0))
            { document.calc.pay.value = "Incomplete data";
            }
            else
            {
                var princ = document.calc.loan.value;
                var term  = document.calc.months.value;
                var intr   = document.calc.rate.value / 1200;
                document.calc.pay.value = princ * intr / (1 - (Math.pow(1/(1 + intr), term)));
            }

// payment = principle * monthly interest/(1 - (1/(1+MonthlyInterest)*Months))

        }

        // -->
    </script>


    <p>
    <center>
        <form name=calc method=POST>
            <table width=60% border=0 style="margin-top: 5%">
                <tr><th bgcolor="#ecb71c" width=50% style="padding: 10px 0px"><font color=black>Description</font></th>
                    <th bgcolor="#ecb71c" width=50%><font color=black>Data Entry</font></th></tr>
                <tr><td bgcolor="#eeeee" style="padding: 10px 0px">Loan Amount</td><td bgcolor="#eeeee" align=right><input
                            type=text name=loan
                            size=10></td></tr>
                <tr><td bgcolor="#eeeee" style="padding: 10px 0px">Loan Length in Months</td><td bgcolor="#eeeee" align=right><input type=text name=months size=10></td></tr>
                <tr><td bgcolor="#eeeee" style="padding: 10px 0px">Interest Rate</td><td bgcolor="#eeeee" align=right><input type=text name=rate size=10></td></tr>
                <tr><td bgcolor="#eeeee" style="padding: 10px 0px">Monthly Payment</td><td bgcolor="#eeeee" align=right><em><font color="black"></font> Calculated</em><input type=text name=pay size=10></td></tr>
               <!-- <tr><td  bgcolor="black" style="padding: 10px 0px"align=center><input type=button onClick='showpay()'
                                                              value=Calculate></td><td bgcolor="black" align=center><input type=reset
                                                                                                                             value=Reset></td></tr>-->
            </table>
        </form>
        <font size, strong=3>Enter only numeric values (no commas), using decimal points
            where needed.<br>
            Non-numeric values will cause errors.</font>
    </center>



    </body>
    </head>
</html>
<?php include ("includes/footer.php");?>