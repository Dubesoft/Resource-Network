<?php
session_start();

//$validatcaptcha= $_SESSION["code"];
include("connect.php");
if(isset($_POST['submit'])){
    $staff_id = $_POST['staff_id'];
    $firstname = $_POST['firstname'];
    $lastname= $_POST['lastname'];
    $email = $_POST['Email'];
   // $username = $_POST['username'];
    $password= $_POST['password'];
    $repass= $_POST['repass'];

    $firstname= stripslashes($firstname);
    $lastname= stripslashes($lastname);
    $email= stripslashes($email);
    $password= trim($password);
   // $username= stripslashes($username);







    if( strlen($password) < 6  )
    { ?>
        <script type="text/javascript">
            alert("Passwords must be greater than 6 characters.");
            window.location="register.php";
        </script>
        <?php
        die();

    }


    if( $password !=$repass)
    { ?>
        <script type="text/javascript">
            alert("Passwords are not identical.");
            window.location="register.php";
        </script>
        <?php
        die();

    }



    $sql=mysqli_query($link,"SELECT * FROM members  WHERE email= '$email'" )or die (mysqli_error($link));
    if(mysqli_num_rows($sql)> 0)
    {


        ?>
        <script type="text/javascript">
            alert("Email address has already been used.");
            window.location="register.php";
        </script>
        <?php

        header("Location: register.php");
        die();
    }



    $password= md5($password);


    $sql="INSERT INTO members set  firstname='$firstname', password= '$password', email= '$email', lastname='$lastname', staff_id= '$staff_id', status = 0, date = NOW()";


    $result=mysqli_query($link, $sql) or die(mysqli_error($link));
/*
    if ($result){


        $to      = $email; // Send email to our user
        $subject = 'Signup | Verification on InsuredHelp.org'; // Give the email a subject
        $message = '
 
Thanks for signing up on InsuredHelp.org!
Your account has been created, you can login with the following credentials after you have activated your account by pressing the url below.
 
------------------------
username: '.$username.'
Password: '.$password.'
------------------------
 
Please click this link to activate your account:
http://www.InsuredHelp.org/verify.php?email='.$email.'
 
'; // Our message above including the link

        $headers = 'From:noreply@InsuredHelp.org' . "\r\n"; // Set from headers
        mail($to, $subject, $message, $headers); // Send our email





*/



        ?>


        <script type="text/javascript">
            alert("Registration sucessful.");
            window.location="login.php";
        </script>

        <?php








}

?>


