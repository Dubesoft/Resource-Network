 <?php 
 session_start();

include ("includes/connect.php");
$m_id = $_SESSION['mid'];
 
 $query = "UPDATE members SET logged = NOW() WHERE id = '$m_id'";
 $result = mysqli_query($connection, $query);

     if ($result){
	
	 ?>
   <script type="text/javascript">
alert("Thank you for your Patronage, we will love to see you back soon!");

window.location="../login.php";
</script>
<?php

die();
   
   }else{

?> 
<script type="text/javascript">
alert("OOps! We were unable to Log you Out");
window.location="dashboard.php";
</script>

<?php
}

     
     
 
    unset($admin1_id);
    $_SESSION = array();
    session_destroy();
    header("Location: adminsignin.php"); 

?>


