<?php include("includes/header.php"); ?>
<?php include("includes/navigation.php"); ?>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2 style="color: #232347" class="col-sm-offset-5">Message</h2>
        <hr>
        <br>
                    </div>
                </div>
                 <!-- /. ROW  -->
                
                                 

                   <!-- /. ROW  -->
            <div class="row">
                <div class="col-md-12 col-sm-8">
                    <div class="panel panel-warning">
                        <div class="panel-heading">
                            Enter your Message Below
                        </div>
                        <form action="process_message.php" method="post">
                            <div class="panel-body">
                            <input type="text" class="form-control transparent" placeholder="Name"  name="name" value=""/>                   
                         </div>
                        <div class="panel-body">
                            <input type="text" class="form-control transparent" placeholder="subject"  name="subject" value=""/>                   
                         </div>
                        <div class="panel-body">
                            <p><textarea name="msg" rows="7" cols="100" class="form-control" placeholder="Message"  style="resize: none;"></textarea></p>
                        </div>
                        <div class="panel-footer">
                            <input type="submit" class="btn btn-success" value="Submit" name="msg_submit">
                        </div>
                        </form>
                    </div>
                </div>
                
                
            </div>
                   <?php include("includes/footer.php"); ?>