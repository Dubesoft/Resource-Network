<?php 
session_start();
include ("connect.php");


    $loan_type = $_POST ['loan_type'];
    $max_credit = $_POST ['max_credit'];
    $psr = $_POST ['psr'];
    $int_rate = $_POST ['int_rate'];
    $max_duration = $_POST ['max_duration'];
    $narration = $_POST ['narration'];
    
    
    //$_SESSION["amount"] = $amount;
    //$_SESSION["trans_type"] = $trans_type;
    //$_SESSION["reason"] = $reason;
    //header ("location: transaction.php");

  
    $query = "INSERT INTO loantype (";
    $query .= " loantype, max_credit, PSR, interest_rate, max_duration, narration";
    $query .= ") VALUES (";
    $query .=" {$loan_type}, {$max_credit}, {$psr}, {$int_rate}, {$max_duration}, '{$narration}'";
    $query .= ")";
    $result = mysqli_query($connection, $query); 
    if($result){
          //$_SESSION["message"] = "Transaction Successful!";
        //header ("location: transaction.php");
        ?>
<script type="text/javascript">
    alert("Operation Successful!");
    window.location="loan_setup.php";
</script>
<?php
    }else{
        //$_SESSION["message"] = "Transaction failed!";
       // header ("location: transaction.php");
        ?>
<script type="text/javascript">
    alert("Operaion failed!");
    window.location="loan_setup.php";
</script>
<?php
    }
    
    
?>