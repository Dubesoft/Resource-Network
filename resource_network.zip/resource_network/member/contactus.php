<?php include ("includes/header.php"); ?>
    <link rel="stylesheet" href="../css/style.css">
<?php include ("includes/Navigation.php"); ?>

    <!-- /. NAV SIDE  -->
    <div id="page-wrapper" >
        <div id="page-inner">
            <form role="form" action="process_transaction.php" method="post" enctype="multipart/form-data">
                <h2 style="color: #232347" class="col-sm-offset-5">Contact Us</h2>

                <br/>


                <div class="form-group input-group">

                </div>
                <div class="form-group input-group">
                    <span class="input-group-addon"><i class="fa fa-tag"  ></i></span>
                    <input type="text" class="form-control" name="name" placeholder="Name " />
                </div>
                <div class="form-group input-group">
                    <span class="input-group-addon"><i class="fa fa-lock"  ></i></span>
                    <input type="password" class="form-control"  name="email" placeholder="Email" />
                </div>

                <div class="form-group input-group">
                    <span class="input-group-addon"><i class="fa fa-tag"  ></i></span>
                    <textarea placeholder="Message" class="form-control" cols="60" rows="5" style="resize: none"></textarea>
                </div>




                <input type="submit" class="btn btn-default btn-md col-sm-offset-5" value="Send">

                <hr />
                <?php //echo $_SESSION["message"];
                //$amount = $_SESSION["amount"];
                // $trans_type = $_SESSION["trans_type"];
                //$reason = $_SESSION["reason"];
                //echo $amount . "<br>";
                //echo $trans_type  . "<br>";
                //echo $reason . "<br>";

                ?>


            </form>




        </div>
        <!-- /. PAGE INNER  -->
    </div>
    <!-- /. PAGE WRAPPER  -->
<?php include ("includes/footer.php"); ?>