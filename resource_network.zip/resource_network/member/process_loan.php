<?php 
session_start();
include ("includes/connect.php");
$m_id = $_SESSION['mid'];

    $member_id = $_POST ['member_id'];
    $amount = $_POST ['amount'];
    $loan_type = $_POST ['loan_type'];
    $reason = $_POST ['reason'];
    
   
$query = "SELECT * ";
$query .= "FROM loantype ";
$query .= "WHERE loantype = '$loan_type' ";         
          //$index = 0;
 $result = mysqli_query($connection, $query);
       	while ( $row = mysqli_fetch_array($result) ) {
		//$row_count =  mysql_num_rows($result);
                $loan_type_id =$row['id'];
		$interest_rate =$row['interest_rate'];
                //$first = $_SESSION['fname'];
                $max_duration =$row['max_duration'];
                $max_credit =$row['max_credit'];
                 $PSR =$row['PSR'];
               
		
        }
    
    
$query = "SELECT * ";
$query .= "FROM members ";
$query .= "WHERE id = '$m_id' ";
$result = mysqli_query($connection, $query);
       	while ( $row = mysqli_fetch_array($result) ) {
                $balance = $row['savedbalance'];
                //$date = $row['date'];
        }
    
  $check = $PSR/100 * $amount;

if ($balance >= $check){
     if ($amount <= $max_credit){
          ?>
<script type="text/javascript">
    alert("Loan Application Successful, wait for the admin approval!");
    window.location="loan_setup.php";
</script>
<?php
     }else{
         ?>
                <script type="text/javascript">
    alert("You can't apply for a loan greater than # "+<?php echo $max_credit; ?>+"!");
    window.location="loan_setup.php";
</script>
<?php
     }

    $query = "INSERT INTO loan (";
    $query .= " applied_date, status, amount, reason, loantype_id, interest, duration, member_id";
    $query .= ") VALUES (";
    $query .=" NOW(), 0, {$amount}, '{$reason}', {$loan_type_id}, {$interest_rate}, {$max_duration}, '{$member_id}'";
    $query .= ")";
    $tresult = mysqli_query($connection, $query);
     
    ?>
<script type="text/javascript">
    alert("Loan Application Successful, wait for the admin approval!");
    window.location="loan_setup.php";
</script>
<?php
}else{
?>
                    <script type="text/javascript">
    alert("You can't apply for a loan greater than "+<?php echo $PSR; ?>+"%");
    window.location="loan_setup.php";
</script>
                    <?php
    
}  
    
    
    
    if($tresult){
        //$_SESSION["message"] = "Transaction Successful!";
        //header ("location: transaction.php");
        ?>
<script type="text/javascript">
    alert("Loan Application  Successful, wait for the admin approval!");
    window.location="loan_setup.php";
</script>
<?php
    }else{
        //$_SESSION["message"] = "Transaction failed!";
       // header ("location: transaction.php");
        ?>
<script type="text/javascript">
    alert("Loan Application failed because you don't have enough money in your account!");
    window.location="loan_setup.php";
</script>
<?php
       
    }
     
    //}
     //header ("location: transaction.php");
?>