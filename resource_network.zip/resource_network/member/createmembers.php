<?php include("includes/header.php"); ?>
<?php include("includes/navigation.php"); ?>  
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                 <form>
        <h2 style="color: #232347" class="col-sm-offset-5">Create Members</h2>
        <br>
        <h4>Photo Upload</h4>
                                    
                                    <input type="hidden" name="MAX_FILE_SIZE" value="1000000">
                                        <p><input type="file" name="file" class="btn btn-default"></p>
                                        <input type="submit" class="btn btn-default" value="Upload Picture" name="upload">
                             
<br>
<br>

                                        <div class="form-group input-group">
                                            <span class="input-group-addon"><span class="input-icon input-icon-user"></span><span class="input-text">First Name</span></span>
                                            <input type="text" class="form-control transparent" placeholder="First Name"  name="fname" value="<?php echo $_SESSION['fname'];?>"/>
                                                
                                        </div>
                                        <div class="form-group input-group">
                                            <span class="input-group-addon"><span class="input-icon input-icon-user"></span><span class="input-text">Last Name</span></span>
                                            <input type="text" class="form-control" placeholder="Last Name"  name="lname" value="<?php echo $_SESSION['lname'];?>"/>
                                                
                                        </div>
                                        <div class="form-group input-group">
                                            <span class="input-group-addon"><span class="input-icon input-icon-email"></span><span class="input-text">Email</span></span>
                                            <input type="text" class="form-control" placeholder="Email" name="email"  value="<?php echo $_SESSION['email'];?>"/>
                                                
                                        </div>

                                     <div class="form-group input-group">
                                            <span class="input-group-addon"><span class="input-icon input-icon-user"></span><span class="input-text">Password</span></span>
                                            <input type="password" class="form-control" placeholder="Password" name="password"/>
                                                
                                        </div>
                                        <div class="form-group input-group">
                                            <span class="input-group-addon"><span class="input-icon input-icon-email"></span><span class="input-text">Address</span></span>
                                            <input type="text" class="form-control" placeholder="Address" name="address"  value="<?php echo $_SESSION['email'];?>"/>
                                                
                                        </div>
                                        <div class="form-group input-group">
                                            <span class="input-group-addon"><span class="input-icon input-icon-email"></span><span class="input-text">Phone Number</span></span>
                                            <input type="text" class="form-control" placeholder="Phone Number" name="phone"  value="<?php echo $_SESSION['email'];?>"/>
                                        </div>
                                        <div class="form-group input-group">                                        
                                                <select name="trans_type" class="chosen-select form-control">
                                                    <option>Gencer</option>
                                                    <option value="male">Male</option>
                                                    <option value="female">Female</option>
                                                </select>
                                            </div>
                                        <div class="form-group input-group">
                                            <span class="input-group-addon"><span class="input-icon input-icon-email"></span><span class="input-text">Saved Balance</span></span>
                                            <input type="text" class="form-control" placeholder="Balance" name="balance"  value="<?php echo $_SESSION['email'];?>"/>
                                        </div>
                                        <div class="form-group input-group">
                                            <span class="input-group-addon"><span class="input-icon input-icon-email"></span><span class="input-text">Date</span></span>
                                            <input type="text" class="form-control" placeholder="Date" name="date"  value="<?php echo $_SESSION['email'];?>"/>
                                        </div>
                                         <a href="#" class="btn btn-default btn-lg col-sm-offset-5">Submit</a>
                                        
          </form>
   
     
      
            </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        <?php include("includes/footer.php"); ?>