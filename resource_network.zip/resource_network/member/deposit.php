<?php
//include ("includes/connect.php");
include ("includes/header.php");
include ("includes/navigation.php");
$member_id = $_SESSION['mid'];

//echo $memberid;
//cho $puname;
/*
$psql="SELECT * FROM photos  WHERE uname = '$puname'" ;
 $presult=mysql_query($psql) or die(mysql_error());
       	while ( $row = mysql_fetch_array($presult) ) {
		
                //$_SESSION['filename'] = null;
		$_SESSION['filename'] =$row['filename'];
                //echo $_SESSION['filename'];
                $imagepath = "photo/".$_SESSION['filename'];
                echo $imagepath;
                
                //echo $_SESSION['fname'];
        }
 * 
 */
echo $member_id;
$query = "SELECT * ";
$query .= "FROM members ";
$query .= "WHERE id = '$member_id' ";
$result = mysqli_query($connection, $query);
//confirm_query($result);
       	while ( $row = mysqli_fetch_array($result) ) {
		
            
		$_SESSION['fname'] =$row['firstname'];
                $_SESSION['lname'] =$row['lastname'];
		$_SESSION['email']= $row['email'];
                //$picture = $row['picture'];
                //$imagepath = "photo/".$picture;
                //echo $imagepath;
        }
       
?>



    

<!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                 <form role="form" action="process_transaction.php" method="post" enctype="multipart/form-data">
                                    <h2 style="color: #232347" class="col-sm-offset-5">Deposit</h2>
                                        
<br/>
                                        
                                            <div class="form-group input-group">                                        
                                                
                                            </div>
                                        <div class="form-group input-group">
                                            <span class="input-group-addon"><span class="input-icon input-icon-user"></span><span class="input-text">Amount</span></span>
                                            <input type="text" class="form-control" placeholder="Amount"  name="amount" required="required"/>
                                        </div>
                                        <div class="form-group input-group">
                                            <span class="input-group-addon"><span class="input-icon input-icon-email"></span><span class="input-text">Reason</span></span>
                                            <input type="text" class="form-control" placeholder="Reason" name="reason" required="required"/>
                                        </div>

                                     
                                        
                                     
                                     
                                     <input type="submit" class="btn btn-default btn-md col-sm-offset-5" value="submit">
                                     
                                    <hr />
                                    <?php //echo $_SESSION["message"];
                                    //$amount = $_SESSION["amount"];
                                           // $trans_type = $_SESSION["trans_type"];
                                            //$reason = $_SESSION["reason"];
                                    //echo $amount . "<br>";
                                    //echo $trans_type  . "<br>";
                                    //echo $reason . "<br>";
                                     
                                    ?>
                                    
                                    <b class="col-lg-offset-11"><?php echo date("d/m/Y")?></b>
                                    </form>
     
      
            </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->

<?php include ("includes/footer.php"); ?>
    