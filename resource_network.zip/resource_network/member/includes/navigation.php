<?php

//include ("connect.php");
//session_start();
$m_id = $_SESSION['mid'];
//$admin_id = $_SESSION['id'];
//echo $memberid;
//cho $puname;
/*
$psql="SELECT * FROM photos  WHERE uname = '$puname'" ;
 $presult=mysql_query($psql) or die(mysql_error());
       	while ( $row = mysql_fetch_array($presult) ) {
		
                //$_SESSION['filename'] = null;
		$_SESSION['filename'] =$row['filename'];
                //echo $_SESSION['filename'];
                $imagepath = "photo/".$_SESSION['filename'];
                echo $imagepath;
                
                //echo $_SESSION['fname'];
        }
*/
$query = "SELECT * ";
$query .= "FROM members ";
$query .= "WHERE id = '$m_id' ";
$result = mysqli_query($connection, $query);
       	while ($row = mysqli_fetch_array($result) ) {	
                $members_count =  mysqli_num_rows($result);
                $picture = $row['picture'];
                $imagepath = "photo/".$picture;
                $fname = $row['firstname'];
                $lname = $row['lastname'];
                $email = $row['email'];
                $staff_id = $row['staff_id'];
                $gender = $row['gender'];
                $address = $row['address'];
                $phone = $row['phonenumber'];
                $balance = $row['savedbalance'];
                //$savedbalance = $row['savedbalance'];
                $date = $row['date'];
                
                
        }
        
        
        $query = "SELECT * ";
$query .= "FROM loan ";
$query .= "WHERE status = '0' ";
$result = mysqli_query($connection, $query);
       	while ($row = mysqli_fetch_array($result) ) {	
                $loan_count =  mysqli_num_rows($result);
  
        }
        
        $query = "SELECT * ";
$query .= "FROM withdraw ";
$query .= "WHERE status = '0' ";
$result = mysqli_query($connection, $query);
       	while ($row = mysqli_fetch_array($result) ) {	
                $withdrawal_count =  mysqli_num_rows($result);
  
        }


        ?>
                <nav class="navbar-default navbar-side" role="navigation" >
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
				<li class="text-center">
                                    <img src="<?php echo $imagepath; ?>" class="user-image img-responsive" alt="user-image"/>
					</li>
                    <?php $link = basename ($_SERVER ['PHP_SELF']); ?>
					
                    <li>
                        <a <?php if ($link == "dashboard.php") {echo 'class="active-menu"';}?>  href="dashboard.php" ><i class="fa fa-dashboard fa-3x"></i> Dashboard</a>
                    </li>
                     <li>
                        <a <?php if ($link == "profile.php") {echo 'class="active-menu"';}?> href="profile.php"><i class="fa fa-desktop fa-3x"></i>Profile</a>
                    </li>
                    <li>
                        <a <?php if ($link == "loan_setup.php") {echo 'class="active-menu"';}?> href="loan_setup.php"><i class="fa fa-cog fa-3x"></i>Apply for Loan</a>
                    </li>
                    <li>
                        <a <?php if ($link == "pending_loan.php") {echo 'class="active-menu"';}?> href="pending_loan.php"><i class="glyphicon glyphicon-log-out fa-3x"></i>Withdraw</a>
                    </li>
                    <li>
                        <a <?php if ($link == "contactus.php") {echo 'class="active-menu"';}?> href="contact.php"><i class="fa fa-envelope fa-3x"></i>Contact Us</a>
                    </li>
                    <li>
                        <a <?php if ($link == "withdrawal_history.php") {echo 'class="active-menu"';}?> href="withdrawal_history.php"><i class="fa fa-history fa-3x"></i>Withdrawal History</a>
                    </li>
                    <li>
                        <a <?php if ($link == "loan_history.php") {echo 'class="active-menu"';}?> href="loan_history.php"><i class="fa fa-history fa-3x"></i>Loan History</a>
                    </li>



                 
                </ul>
               
            </div>
            
        </nav> 