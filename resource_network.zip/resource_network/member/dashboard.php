<?php include("includes/header.php"); ?>
<?php include("includes/navigation.php"); ?>

<?php error_reporting(0); ?>
<?php


        $hour = date("H");
        if($hour >= 20){
            $greeting = "Good Night ". $fname . " ". $_lname. " , Have a good night rest.";
        }elseif ($hour > 17) {
            $greeting = "Good Evening ". $fname ." ". $lname. ", Hope you enjoyed your day?";  
        }elseif ($hour > 11) {
            $greeting = "Good Afternoon ". $fname . " ". $lname. ", How is your day coming?";  
        }elseif ($hour < 12) {
            $greeting = "Good Morning ". $fname ." ".$lname. ", How was your night?";  
        }


?>

        <!-- /. NAV SIDE  -->
    <div id="page-wrapper" >
    <div id="page-inner">
        <div class="row">
            <div class="col-md-12">
                <!--<h2 style="color:black;">Member Profile</h2>-->
                <h3><?php echo $greeting; ?></h3>
                <?php echo $dashboard; ?>
                
            </div>
        </div>
        <!-- /. ROW  -->
        <hr />
        <div class="row">
            <div class="col-md-3 col-sm-6 col-xs-6">
                <div class="panel panel-back noti-box">
                <span class="icon-box bg-color-red set-icon">
                    <i class="fa fa-envelope-o"></i>
                </span>
                    <div class="text-box" >
                        <p class="main-text">saved Balance: <?php echo "&#8358 ". number_format($balance, 2); ?></p>
                        <p class="text-muted">Message</p>
                    </div>
                </div>
            </div>


            <div class="col-md-3 col-sm-6 col-xs-6">
                <div class="panel panel-back noti-box">
                <span class="icon-box bg-color-blue set-icon">
                    <i class="fa fa-bell-o"></i>
                </span>
                    <div class="text-box" >
                        <p class="main-text">Number of Withdrawals: <?php echo $withdrawal_count; ?></p>
                        <p class="text-muted">Notifications</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-xs-6">
                <div class="panel panel-back noti-box">
                <span class="icon-box bg-color-blue set-icon">
                    <i class="fa fa-bell-o"></i>
                </span>
                    <div class="text-box" >
                        <p class="main-text">Pending Loans: <?php echo $loan_count; ?></p>
                        <p class="text-muted">Notifications</p>
                    </div>
                </div>
            </div>


        </div>
        <!-- /. ROW  -->
        <hr />

        <!-- /. PAGE INNER  -->
    </div>
         <!-- /. PAGE WRAPPER  -->
<?php include("includes/footer.php"); ?>