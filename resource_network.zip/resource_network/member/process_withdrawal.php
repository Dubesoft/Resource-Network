<?php 
session_start();
include ("includes/connect.php");
$m_id = $_SESSION['mid'];

    $amount = $_POST ['amount'];
    $member_id = $_POST ['member_id'];
    $reason = $_POST ['reason'];
    
$query = "SELECT * ";
$query .= "FROM deposit ";
$query .= "WHERE member_id = '$member_id' ";
$result = mysqli_query($connection, $query);
       	while ( $row = mysqli_fetch_array($result) ) {    
            $deposit_count =  mysqli_num_rows($result);
        }
        
$query = "SELECT * ";
$query .= "FROM members ";
$query .= "WHERE id = '$m_id' ";
$result = mysqli_query($connection, $query);
       	while ( $row = mysqli_fetch_array($result) ) {
                $balance = $row['savedbalance'];
                $date = $row['date'];
                
        }
        
$query = "SELECT * ";
$query .= "FROM withdrawal_policy ";
$result = mysqli_query($connection, $query);
       	while ( $row = mysqli_fetch_array($result) ) {
                $no_deposit = $row['no_deposit'];
                $percentage = $row['percentage'];
                $duration = $row['duration'];
                
        }
        
       // echo "deposit no: ".$no_deposit . "<br>";
       // echo "Percentage: ". $percentage . "<br>";
       // echo "duration: ".$duration . "<br>";
        /*
        echo "The number of deposit is: " . $deposit_count;
         $before = date('m', strtotime($date));
         $now = date('m');
         if ($now > $before){
            echo "You are not eligible";
         }else{
             echo "You are eligible";
         }
         * 
         */
       //echo strtotime(date("Y-m-d")) . "<br>";
       // $timestamp = strtotime("today");
        //$time = date("Y-m-d");
         //echo $timestamp . "<br>";
         //echo time();
         //echo $date;
        $before = date('m', strtotime($date));
        $now = date('m');
        $check = $percentage/100 * $balance;
        //echo $check;
        $date_diff = $now - $before;
        //echo "The months difference is: " . $date_diff; 
        if ($amount <= $check){
            if ($deposit_count >= $no_deposit){
                if($date_diff >= $duration){
                    //echo "Are criteria has been satisfied";
            $query = "INSERT INTO withdraw (";
            $query .= " member_id, date_applied, status, amount, reason";
            $query .= ") VALUES (";
            $query .=" '$member_id', NOW(), 0, {$amount}, '{$reason}'";
            $query .= ")";

            $wresult = mysqli_query($connection, $query);
            
            ?>
<script type="text/javascript">
    alert("Withdrawal Application Successful!");
    window.location="pending_loan.php";
</script>
<?php
    


            
                }else{
                    ?>
                    <script type="text/javascript">
    alert("You haven't stayed up to 3 months in the system!");
    window.location="pending_loan.php";
</script>
                    <?php
                    // echo "You haven't stayed up to 3 months in the system.";
                }
                 ?>
<script type="text/javascript">
    alert("Withdrawal Application Successful!");
    window.location="pending_loan.php";
</script>
<?php
                
                
                
            }else{
                ?>
                <script type="text/javascript">
    alert("You haven't deposited up up to 3 times!");
    window.location="pending_loan.php";
</script>
<?php
                // echo "You haven't deposited up to 3";
            }
            
        }else{
            
           // echo "You don't have up to 50% of your balance";
        
    //$_SESSION["amount"] = $amount;
    //$_SESSION["trans_type"] = $trans_type;
    //$_SESSION["reason"] = $reason;
    //header ("location: transaction.php");

    /*
    $query = "INSERT INTO trans (";
    $query .= " trans_date, trans_type, amount, narration";
    $query .= ") VALUES (";
    $query .=" NOW(), {$trans_type}, {$amount}, '{$reason}'";
    $query .= ")";
    
    
    $tresult = mysqli_query($connection, $query);
    /*
    if($result){
        $_SESSION["message"] = "Transaction Successful!";
        header ("location: transaction.php");
    }else{
        $_SESSION["message"] = "Transaction failed!";
        header ("location: transaction.php");
        echo "The content is: " . $query;
    }
    
     * 
     */
     
    //if($trans_type == "1"){
        

/*    if($wresult){
        $_SESSION["message"] = "Transaction Successful!";
        header ("location: pending_loan.php");
    }else{
        $_SESSION["message"] = "Transaction failed!";
        header ("location: pending_loan.php");
        echo "The content is: " . $query;
    }
     header ("location: pending_loan.php");
 * 
 */
if($wresult){
        //$_SESSION["message"] = "Transaction Successful!";
        //header ("location: transaction.php");
        ?>
<script type="text/javascript">
    alert("Withdrawal Application Successful!");
    window.location="pending_loan.php";
</script>
<?php
    }else{
        //$_SESSION["message"] = "Transaction failed!";
       // header ("location: transaction.php");
        ?>
<script type="text/javascript">
    alert("You don't have up to 50% of your balance!");
    window.location="pending_loan.php";
</script>
<?php
    }
        }
        
    //}
     //header ("location: transaction.php");
?>