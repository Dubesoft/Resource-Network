<?php include("includes/header.php"); ?>
<?php include("includes/navigation.php"); ?>
<?php
session_start();
include ("includes/connect.php");
$member_id = $_SESSION['mid'];
/*
//echo $memberid;
//cho $puname;
/*
$psql="SELECT * FROM photos  WHERE uname = '$puname'" ;
 $presult=mysql_query($psql) or die(mysql_error());
       	while ( $row = mysql_fetch_array($presult) ) {
		
                //$_SESSION['filename'] = null;
		$_SESSION['filename'] =$row['filename'];
                //echo $_SESSION['filename'];
                $imagepath = "photo/".$_SESSION['filename'];
                echo $imagepath;
                
                //echo $_SESSION['fname'];
        }
 * 
 */
echo $member_id;
$query = "SELECT * ";
$query .= "FROM members ";
$query .= "WHERE id = '$member_id' ";
$result = mysqli_query($connection, $query);
//confirm_query($result);
       	while ( $row = mysqli_fetch_array($result) ) {
		
            
		$_SESSION['fname'] =$row['firstname'];
                $_SESSION['lname'] =$row['lastname'];
		$_SESSION['email']= $row['email'];
                //$picture = $row['picture'];
                //$imagepath = "photo/".$picture;
                //echo $imagepath;
        }
        
        $hour = date("H");
        if($hour >= 20){
            $greeting = "Good Night ". $_SESSION['fname'] . ", Have a good night rest.";
        }elseif ($hour > 17) {
            $greeting = "Good Evening ". $_SESSION['fname'] . ", Hope you enjoyed your day?";  
        }elseif ($hour > 11) {
            $greeting = "Good Afternoon ". $_SESSION['fname'] . ", How is your day coming?";  
        }elseif ($hour < 12) {
            $greeting = "Good Morning ". $_SESSION['fname'] . ", How was your night?";  
        }

?>



<!DOCTYPE html>
<html>
<head>
    
    
    <link href='//fonts.googleapis.com/css?family=PT+Sans:400,700,400italic,700italic%7CPT+Gudea:400,700,400italic%7CPT+Oswald:400,700,300' rel='stylesheet' id="googlefont">
        
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/prettyPhoto.css">
        <link rel="stylesheet" href="css/owl.carousel.css">
        <link rel="stylesheet" href="css/jquery.selectbox.css">
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/responsive.css">
        
        <!-- Favicon and Apple Icons -->
        <link rel="icon" type="image/png" href="images/icons/icon.png">
        <link rel="apple-touch-icon" sizes="57x57" href="images/icons/apple-icon-57x57.png">
        <link rel="apple-touch-icon" sizes="72x72" href="images/icons/apple-icon-72x72.png">
        
        <!--- jQuery -->
        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
        <script>window.jQuery || document.write('<script src="js/jquery-1.11.1.min.js"><\/script>')</script>

        <!--[if lt IE 9]>
            <script src="js/html5shiv.js"></script>
            <script src="js/respond.min.js"></script>
        <![endif]-->
    
    
    
    
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Profile Details</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

   
   
   
   
</head>
<body>
    <div class="container">
        <div class="row text-center  ">
            <div class="col-md-12">
                <br /><br />
                <h1 style="font-family: Le Griffe; color: red; font-size: 50px;"><b>Transaction</b></h1>
               
                
                 <br />
            </div>
        </div>
         <div class="row">
               
                <div class="col-md-8 col-md-offset-2 col-sm-6 col-sm-offset-3 col-xs-10 col-xs-offset-1">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <marquee direction="left"><strong style="color: maroon; font-size: 20px;"><?php echo $greeting; ?></strong></marquee>  
                            </div>
                            <div class="panel-body">
                                <form role="form" action="process_transaction.php" method="post" enctype="multipart/form-data">
                                    
                                        
<br/>
                                        
                                            <div class="form-group input-group">                                        
                                                <select name="trans_type" class="chosen-select form-control">
                                                    <option>Select Transaction Type</option>
                                                    <option value="0">Deposit</option>
                                                    <option value="1">Withdrawal</option>
                                                </select>
                                            </div>
                                        <div class="form-group input-group">
                                            <span class="input-group-addon"><span class="input-icon input-icon-user"></span><span class="input-text">Amount</span></span>
                                            <input type="text" class="form-control" placeholder="Amount"  name="amount" required="required"/>
                                        </div>
                                        <div class="form-group input-group">
                                            <span class="input-group-addon"><span class="input-icon input-icon-email"></span><span class="input-text">Reason</span></span>
                                            <input type="text" class="form-control" placeholder="Reason" name="reason" required="required"/>
                                        </div>

                                     
                                        
                                     
                                     <a href="profile.php" class="btn btn-default btn-md">Profile</a>
                                     <input type="submit" class="btn btn-default btn-md col-sm-offset-1" value="submit">
                                     <a href="loan.php" class="btn btn-default btn-md col-sm-offset-1">Apply for Loan</a>
                                        <a href="EditProfile.php" class="btn btn-default btn-md col-sm-offset-1">Edit</a>
                                        <a href="Logout.php" class="btn btn-default btn-md col-sm-offset-1">Log Out</a>   
                                    <hr />
                                    <?php //echo $_SESSION["message"];
                                    //$amount = $_SESSION["amount"];
                                           // $trans_type = $_SESSION["trans_type"];
                                            //$reason = $_SESSION["reason"];
                                    //echo $amount . "<br>";
                                    //echo $trans_type  . "<br>";
                                    //echo $reason . "<br>";
                                     
                                    ?>
                                    
                                   <!-- <b class="col-lg-offset-11"><?php echo date("d/m/Y")?></b>-->
                                    </form>
                            </div>
                           
                        </div>
                    </div>
                
            
                
        </div>
    </div>


     <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
   
    
    
    
    <script src="js/bootstrap.min.js"></script>
    <script src="js/smoothscroll.js"></script>
	<script src="js/jquery.debouncedresize.js"></script>
    <script src="js/retina.min.js"></script>
    <script src="js/jquery.placeholder.js"></script>
    <script src="js/jquery.hoverIntent.min.js"></script>
	<script src="js/twitter/jquery.tweet.min.js"></script>
	<script src="js/jquery.flexslider-min.js"></script>
    <script src="js/jquery.selectbox.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
	<script src="js/main.js"></script>
</body>
</html>
