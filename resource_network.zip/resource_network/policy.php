<?php include("includes/header.php");?>
			<!-- site content -->
			<div id="main">
			<!-- Breadcrumb Section Start Here -->
				<div class="breadcrumb-section">
					<div class="container">
						<div class="row">
							<div class="col-xs-12">
								<h1>Our Mission</h1>
								<ul class="breadcrumb">
									<li>
										<a href="index.html">Home</a>
									</li>
									<li class="active">
										Our Mission
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			<!-- Breadcrumb Section End Here -->

				<div class="content-wrapper" id="page-info">
					<div class="container">
						<!-- Our Story Section Start Here -->
						<section class="our-story row">
							<div class="col-xs-12">
								<header class="story-heading section-header">
									<h2>Who we are? <strong>Read our Story</strong></h2>
								</header>
								<div class="row">
									<div class="col-xs-12 col-sm-5">
										<section class="slider-wrap flex-slide flexslider">
											<ul class="slides">
											<li>
												<img src="assets/img/img-slide-01.jpg" alt="">
											</li>
											<li>
												<img src="assets/img/img-slide-02.jpg" alt="">
											</li>
											</ul>
										</section>
									</div>
									<div class="col-xs-12 col-sm-7">
										<strong class="article-sammury">

                                            The main objective of the society is to promotes the savings habit of the members and to grant loans to them for useful purpose with an ultimate aim of improving the living standard of the members.
                                            <p>
                                                The society continues to progress and offers to meet the expectations of the members.
										</strong>
										<p>
										We do not raise fund for ourselves. Indeed, we use all the funds that come through charity in the best of the best way in terms of holistic development of children of all age groups. Our team is relentlessly working day and night to ensure that there will no hassle for our fund donor.
										</p>
										<p>
											We work for children welfare, who are daily exploited and living in the condition deprived of healthy environment, proper eduction, food, cloth and medical care. 
										</p>
									</div>
								</div>
							</div>
						</section>
						<!-- Our Story Section Start Here -->
						<!-- What We Do Section Start Here-->
						<section class="our-works row anim-section">
							<div class="col-xs-12">
								<header class="work-block-heading section-header">
									<h2>What we do? <strong>See Our Works</strong></h2>
								</header>
								<div class="row">
									<div class="col-xs-12 col-sm-6 col-md-3">
										<div class="thumbnail zoom">
											<h3>Personal Funds</h3>
											<a href="blog-full-width.html" class="img-thumb">
												<figure>
												<img src="assets/img/img-slide-01.jpg" alt="">
												</figure>
												</a>
											<p>
												We support to you raise fund for charity causes that can be used to improve the quality of African children, who are living in the worst condition.
											</p>
											<p>
												<a href="blog-full-width.html" class="btn btn-default btn-sm" role="button">READ MORE</a>
											</p>
										</div>
									</div>
									<div class="col-xs-12 col-sm-6 col-md-3">
										<div class="thumbnail zoom">
											<h3>Creative Events</h3>
											<a href="blog-full-width.html" class="img-thumb">
												<figure>
												<img src="assets/img/img-slide-02.jpg" alt="">
												</figure>
												</a>
											<p>
												Charity organizes different event to raise money for children’s welfare. We have generated around 80% of the resource through different events. 
											</p>
											<p>
												<a href="blog-full-width.html" class="btn btn-default btn-sm" role="button">READ MORE</a>
											</p>
										</div>
									</div>
									<div class="col-xs-12 col-sm-6 col-md-3">
										<div class="thumbnail zoom">
											<h3>Sponsorships</h3>
											<a href="blog-full-width.html" class="img-thumb">
												<figure>
												<img src="assets/img/img-slide-05.jpg" alt="">
												</figure>
												</a>
											<p>
												Our sponsorships program has not only helped us achieve mission, but also helped sponsor boost their businesses.
											</p>
											<p>
												<a href="blog-full-width.html" class="btn btn-default btn-sm" role="button">READ MORE</a>
											</p>
										</div>
									</div>
									<div class="col-xs-12 col-sm-6 col-md-3">
										<div class="thumbnail">
											<h3>Investors</h3>
											<a href="blog-full-width.html" class="img-thumb">
												<figure>
												<img src="assets/img/img-slide-03.jpg" alt="">
												</figure>
												</a>
											<p>
												Join us? Be a part of our family of investors, whose contribution have propelled us to reach to the envisioned goal without any problem. 
											</p>
											<p>
												<a href="blog-full-width.html" class="btn btn-default btn-sm" role="button">READ MORE</a>
											</p>
										</div>
									</div>
								</div>
							</div>
						</section>
						<!-- What We Do Section Start Here-->
					</div>

					<!-- Helping Section Start here-->
					<section class="helping-child parallax">
						<div class="container">
							<div class="row">
								<div class="col-xs-12 col-sm-7 col-md-5">
									<h2 class="h1">Helping child in <strong class="border-none">Africa</strong></h2>
									<p>You are Just A Few Clicks Away To Bring Smile To Children. </p>
									<a data-toggle="modal" href="external.html" data-target=".donate-form" class="btn btn-theme">Donate now</a>
								</div>
							</div>
						</div>
					</section>
					<!-- Helping Section Start here-->

					<!-- Our Team Section Start Here -->
					<div class="container">
						<div class="our-team text-center row">
							<div class="col-xs-12">
								<header class="team-info section-header">
									<h2>We are Real. <strong class="border-none">Meet the Team</strong></h2>
								</header>
								<div class="row">
									<div class="col-xs-12 col-sm-3 anim-section">
										<div class="thumbnail">
											<figure>
											<img src="assets/img/team-member1.jpg" alt="">
											</figure>
											<div class="caption">
												<h3>Jhony Waker</h3>
												<ul class="social-icons">
													<li>
														<a href="#"><i class="fa fa-facebook"></i></a>
													</li>
													<li>
														<a href="#"><i class="fa fa-twitter"></i></a>
													</li>
													<li>
														<a href="#"><i class="fa fa-pinterest"></i></a>
													</li>
													<li>
														<a href="#"><i class="fa fa-google-plus"></i></a>
													</li>
													<li>
														<a href="#"><i class="fa fa-instagram"></i></a>
													</li>
												</ul>
											</div>
										</div>
									</div>
									<div class="col-xs-12 col-sm-3 anim-section">
										<div class="thumbnail">
											<figure>
											<img src="assets/img/team-member2.jpg" alt="">
											</figure>
											<div class="caption">
												<h3>Tony Vedvik</h3>
												<ul class="social-icons">
													<li>
														<a href="#"><i class="fa fa-facebook"></i></a>
													</li>
													<li>
														<a href="#"><i class="fa fa-twitter"></i></a>
													</li>
													<li>
														<a href="#"><i class="fa fa-pinterest"></i></a>
													</li>
													<li>
														<a href="#"><i class="fa fa-google-plus"></i></a>
													</li>
													<li>
														<a href="#"><i class="fa fa-instagram"></i></a>
													</li>
												</ul>
											</div>
										</div>
									</div>
									<div class="col-xs-12 col-sm-3 anim-section">
										<div class="thumbnail">
											<figure>
											<img src="assets/img/team-member3.jpg" alt="">
											</figure>
											<div class="caption">
												<h3>John Doe </h3>
												<ul class="social-icons">
													<li>
														<a href="#"><i class="fa fa-facebook"></i></a>
													</li>
													<li>
														<a href="#"><i class="fa fa-twitter"></i></a>
													</li>
													<li>
														<a href="#"><i class="fa fa-pinterest"></i></a>
													</li>
													<li>
														<a href="#"><i class="fa fa-google-plus"></i></a>
													</li>
													<li>
														<a href="#"><i class="fa fa-instagram"></i></a>
													</li>
												</ul>
											</div>
										</div>
									</div>
									<div class="col-xs-12 col-sm-3 anim-section">
										<div class="thumbnail">
											<figure>
											<img src="assets/img/team-member4.jpg" alt="">
											</figure>
											<div class="caption">
												<h3>Bryant Cranford</h3>
												<ul class="social-icons">
													<li>
														<a href="#"><i class="fa fa-facebook"></i></a>
													</li>
													<li>
														<a href="#"><i class="fa fa-twitter"></i></a>
													</li>
													<li>
														<a href="#"><i class="fa fa-pinterest"></i></a>
													</li>
													<li>
														<a href="#"><i class="fa fa-google-plus"></i></a>
													</li>
													<li>
														<a href="#"><i class="fa fa-instagram"></i></a>
													</li>
												</ul>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<!-- Our Team Section Start Here -->

				</div>

			</div>
			<!-- site content ends -->

<?php include ("includes/footer.php");?>