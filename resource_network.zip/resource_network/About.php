<?php include("includes/header.php");?>
    <!-- site content -->
    <div id="main">
        <!-- Breadcrumb Section Start Here -->

        </div>
        <!-- Breadcrumb Section End Here -->

        <div class="content-wrapper" id="page-info">
            <div class="container">
                <!-- Our Story Section Start Here -->
                <section class="our-story row">
                    <div class="col-xs-12">
                        <header class="story-heading section-header">
                            <h2 style="color: darkblue"> <strong>About Us</strong></h2>
                        </header>
                        <div class="row">
                            <div class="col-xs-12 col-sm-5">
                                <section class="slider-wrap flex-slide flexslider">
                                    <ul class="slides">
                                        <li>
                                            <img src="assets/img/new/aboutus.jpeg" alt="about us">
                                        </li>
                                        <li>
                                            <img src="assets/img/new/obj.png" alt="about us">
                                        </li>
                                        <li>
                                            <img src="assets/img/new/im.jpg" alt="about us">
                                        </li>
                                    </ul>
                                </section>
                            </div>
                            <div class="col-xs-12 col-sm-7">
                                <strong class="article-sammury">

                                    The main objective of the society is to promotes the savings habit of the members and to grant loans to them for useful purpose with an ultimate aim of improving the living standard of the members.
                                    <p>
                                        The society continues to progress and offers to meet the expectations of the members.
                                </strong>

                            </div>
                        </div>
                    </div>
                </section>
                <!-- Our Story Section Start Here -->
                <!-- What We Do Section Start Here-->
            </div>
        </div>
    </div>


<?php include ("includes/footer.php");?>