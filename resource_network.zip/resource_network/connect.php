<?php
$link = mysqli_connect("localhost","root","") or die(mysqli_error());
$db='resource_network';
if (!$link) {
  echo( '<p>Unable to connect to the ' .
        'database server at this time.</p>' );
  exit();
}
$db=mysqli_select_db($link,$db) or die(mysqli_error());
if( !$db){
 die("Couldn't connect to the database at all");
}




